/**
 * Authentication Controller
 * Handles user registration, login, and authentication
 */

const jwt = require('jsonwebtoken');
const UserModel = require('../models/User');
const { AppError } = require('../middleware/errorHandler');

class AuthController {
  /**
   * Register a new student
   */
  static async register(req, res, next) {
    try {
      const { firstName, lastName, email, password, school } = req.body;

      // Validate input
      if (!firstName || !lastName || !email || !password) {
        throw new AppError('Please provide all required fields', 400);
      }

      // Check if email already exists
      const emailExists = await UserModel.emailExists(email);
      if (emailExists) {
        throw new AppError('Email already registered', 409);
      }

      // Create user
      const user = await UserModel.create({
        firstName,
        lastName,
        email,
        password,
        role: 'student',
        school
      });

      // Generate JWT token
      const token = jwt.sign(
        {
          userId: user.user_id,
          email: user.email,
          role: user.role
        },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRE || '7d' }
      );

      res.status(201).json({
        success: true,
        message: 'Registration successful',
        data: {
          user: {
            id: user.user_id,
            firstName: user.first_name,
            lastName: user.last_name,
            email: user.email,
            role: user.role,
            school: user.school_institution
          },
          token
        }
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Login user
   */
  static async login(req, res, next) {
    try {
      const { email, password } = req.body;

      // Validate input
      if (!email || !password) {
        throw new AppError('Please provide email and password', 400);
      }

      // Find user
      const user = await UserModel.findByEmail(email);
      if (!user) {
        throw new AppError('Invalid credentials', 401);
      }

      // Check if account is active
      if (!user.is_active) {
        throw new AppError('Account is deactivated', 403);
      }

      // Verify password
      const isPasswordValid = await UserModel.verifyPassword(password, user.password_hash);
      if (!isPasswordValid) {
        throw new AppError('Invalid credentials', 401);
      }

      // Generate JWT token
      const token = jwt.sign(
        {
          userId: user.user_id,
          email: user.email,
          role: user.role
        },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRE || '7d' }
      );

      res.json({
        success: true,
        message: 'Login successful',
        data: {
          user: {
            id: user.user_id,
            firstName: user.first_name,
            lastName: user.last_name,
            email: user.email,
            role: user.role,
            school: user.school_institution
          },
          token
        }
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Get current user profile
   */
  static async getProfile(req, res, next) {
    try {
      const user = await UserModel.findById(req.user.userId);

      if (!user) {
        throw new AppError('User not found', 404);
      }

      res.json({
        success: true,
        data: {
          user: {
            id: user.user_id,
            firstName: user.first_name,
            lastName: user.last_name,
            email: user.email,
            role: user.role,
            school: user.school_institution,
            phone: user.phone,
            profilePicture: user.profile_picture
          }
        }
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Update user profile
   */
  static async updateProfile(req, res, next) {
    try {
      const { firstName, lastName, school, phone } = req.body;

      const updatedUser = await UserModel.update(req.user.userId, {
        firstName,
        lastName,
        school,
        phone
      });

      res.json({
        success: true,
        message: 'Profile updated successfully',
        data: {
          user: {
            id: updatedUser.user_id,
            firstName: updatedUser.first_name,
            lastName: updatedUser.last_name,
            email: updatedUser.email,
            role: updatedUser.role,
            school: updatedUser.school_institution,
            phone: updatedUser.phone
          }
        }
      });
    } catch (error) {
      next(error);
    }
  }
}

module.exports = AuthController;
