/**
 * Payment Service
 * Handles all payment-related API calls
 */

import { post, get } from '../utils/api';
import { API_ENDPOINTS } from '../constants/apiConfig';

export const paymentService = {
  /**
   * Process payment
   */
  async processPayment(paymentData) {
    return await post(API_ENDPOINTS.PROCESS_PAYMENT, paymentData);
  },

  /**
   * Verify payment
   */
  async verifyPayment(paymentId) {
    return await post(API_ENDPOINTS.VERIFY_PAYMENT, { paymentId });
  },

  /**
   * Get payment history
   */
  async getPaymentHistory() {
    return await get(API_ENDPOINTS.PAYMENT_HISTORY);
  },

  /**
   * Create payment intent (for Stripe, etc.)
   */
  async createPaymentIntent(amount, currency = 'USD') {
    return await post('/payments/create-intent', { amount, currency });
  }
};
