import { useCallback } from 'react';
import { useApp } from '../contexts/AppContext';

export function useNotification() {
  const { addNotification } = useApp();

  const success = useCallback((message) => {
    addNotification(message, 'success');
  }, [addNotification]);

  const error = useCallback((message) => {
    addNotification(message, 'error');
  }, [addNotification]);

  const warning = useCallback((message) => {
    addNotification(message, 'warning');
  }, [addNotification]);

  const info = useCallback((message) => {
    addNotification(message, 'info');
  }, [addNotification]);

  return {
    success,
    error,
    warning,
    info,
  };
}
