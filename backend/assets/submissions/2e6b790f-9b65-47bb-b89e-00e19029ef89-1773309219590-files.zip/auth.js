/**
 * Authentication Routes
 * Routes for user registration and login
 */

const express = require('express');
const router = express.Router();
const AuthController = require('../controllers/authController');
const { authenticate } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

// Public routes
router.post('/register', asyncHandler(AuthController.register));
router.post('/login', asyncHandler(AuthController.login));

// Protected routes
router.get('/profile', authenticate, asyncHandler(AuthController.getProfile));
router.put('/profile', authenticate, asyncHandler(AuthController.updateProfile));

module.exports = router;
