import React from 'react';
import { LEVEL_CONFIG } from '../../constants/levelConfig';

export default function StudentTable({ students, onSelectStudent }) {
  return (
    <div className="bg-slate-900/50 backdrop-blur-xl rounded-2xl border border-slate-800 overflow-hidden">
      <div className="px-6 py-4 border-b border-slate-800">
        <h3 className="font-semibold text-white">All Students</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-slate-800/50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase">Student</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase">Level</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase">Progress</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase">Started</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {students.map((student) => {
              const config = LEVEL_CONFIG[student.level];
              const progress = (student.completedSessions / config.sessions) * 100;
              
              return (
                <tr key={student.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-6 py-4">
                    <div>
                      <div className="font-medium text-white">{student.firstName} {student.lastName}</div>
                      <div className="text-sm text-slate-400">{student.email}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded text-sm font-semibold ${config.colorClasses.bgLight} ${config.colorClasses.text}`}>
                      {student.level}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-2">
                      <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden max-w-[100px]">
                        <div className={`h-full ${config.colorClasses.bg}`} style={{ width: `${progress}%` }} />
                      </div>
                      <span className="text-sm text-slate-400 w-16">{student.completedSessions}/{config.sessions}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-400">
                    {new Date(student.internshipStartDate).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded text-sm font-semibold ${
                      student.paymentConfirmed
                        ? 'bg-green-500/20 text-green-400'
                        : 'bg-amber-500/20 text-amber-400'
                    }`}>
                      {student.paymentConfirmed ? 'Active' : 'Pending'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => onSelectStudent(student)}
                      className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm transition-colors"
                    >
                      View Details
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
