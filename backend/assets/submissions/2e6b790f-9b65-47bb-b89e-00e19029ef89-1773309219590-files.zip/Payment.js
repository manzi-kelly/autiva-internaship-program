/**
 * Payment Model
 * Handles all database operations related to payments
 */

const db = require('../config/database');
const { v4: uuidv4 } = require('uuid');

class PaymentModel {
  /**
   * Create a new payment record
   * @param {Object} paymentData - Payment data
   * @returns {Promise<Object>} Created payment
   */
  static async create(paymentData) {
    const { userId, levelId, amount, paymentMethod } = paymentData;
    const transactionId = uuidv4();
    
    const client = await db.getClient();
    
    try {
      await client.query('BEGIN');
      
      // Create payment record
      const paymentQuery = `
        INSERT INTO payments (user_id, level_id, amount, payment_method, transaction_id, status)
        VALUES ($1, $2, $3, $4, $5, 'pending')
        RETURNING payment_id, user_id, level_id, amount, transaction_id, status, created_at
      `;
      
      const paymentResult = await client.query(paymentQuery, [
        userId, levelId, amount, paymentMethod, transactionId
      ]);
      
      // Create student progress record
      const progressQuery = `
        INSERT INTO student_progress (user_id, level_id, payment_id, status)
        VALUES ($1, $2, $3, 'not_started')
        ON CONFLICT (user_id, level_id) DO NOTHING
      `;
      
      await client.query(progressQuery, [userId, levelId, paymentResult.rows[0].payment_id]);
      
      await client.query('COMMIT');
      
      return paymentResult.rows[0];
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Verify and complete payment
   * @param {number} paymentId - Payment ID
   * @param {number} verifiedBy - Supervisor user ID
   * @returns {Promise<Object>} Updated payment
   */
  static async verifyPayment(paymentId, verifiedBy) {
    const client = await db.getClient();
    
    try {
      await client.query('BEGIN');
      
      // Update payment status
      const paymentQuery = `
        UPDATE payments
        SET status = 'completed',
            paid_at = CURRENT_TIMESTAMP,
            verified_by = $1,
            verified_at = CURRENT_TIMESTAMP
        WHERE payment_id = $2
        RETURNING *
      `;
      
      const paymentResult = await client.query(paymentQuery, [verifiedBy, paymentId]);
      
      if (paymentResult.rows.length === 0) {
        throw new Error('Payment not found');
      }
      
      const payment = paymentResult.rows[0];
      
      // Update student progress and start internship (trigger will handle this)
      // Also create submissions for all tasks
      const submissionsQuery = `
        INSERT INTO submissions (user_id, task_id, session_id, deadline, status)
        SELECT 
          $1,
          t.task_id,
          t.session_id,
          CURRENT_TIMESTAMP + (s.duration_hours || ' hours')::INTERVAL,
          'not_started'
        FROM tasks t
        JOIN sessions s ON t.session_id = s.session_id
        WHERE s.level_id = $2
        ON CONFLICT (user_id, task_id) DO NOTHING
      `;
      
      await client.query(submissionsQuery, [payment.user_id, payment.level_id]);
      
      await client.query('COMMIT');
      
      return payment;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Get payment by ID
   * @param {number} paymentId - Payment ID
   * @returns {Promise<Object>} Payment data
   */
  static async getById(paymentId) {
    const query = `
      SELECT p.*, u.first_name, u.last_name, u.email, l.level_name
      FROM payments p
      JOIN users u ON p.user_id = u.user_id
      JOIN levels l ON p.level_id = l.level_id
      WHERE p.payment_id = $1
    `;
    
    const result = await db.query(query, [paymentId]);
    return result.rows[0];
  }

  /**
   * Get all pending payments
   * @returns {Promise<Array>} List of pending payments
   */
  static async getPendingPayments() {
    const query = `
      SELECT p.*, u.first_name, u.last_name, u.email, l.level_name
      FROM payments p
      JOIN users u ON p.user_id = u.user_id
      JOIN levels l ON p.level_id = l.level_id
      WHERE p.status = 'pending'
      ORDER BY p.created_at DESC
    `;
    
    const result = await db.query(query);
    return result.rows;
  }

  /**
   * Get user's payment history
   * @param {number} userId - User ID
   * @returns {Promise<Array>} Payment history
   */
  static async getUserPayments(userId) {
    const query = `
      SELECT p.*, l.level_name
      FROM payments p
      JOIN levels l ON p.level_id = l.level_id
      WHERE p.user_id = $1
      ORDER BY p.created_at DESC
    `;
    
    const result = await db.query(query, [userId]);
    return result.rows;
  }

  /**
   * Check if user has active payment for level
   * @param {number} userId - User ID
   * @param {string} levelId - Level ID
   * @returns {Promise<boolean>} Has active payment
   */
  static async hasActivePayment(userId, levelId) {
    const query = `
      SELECT payment_id
      FROM payments
      WHERE user_id = $1 AND level_id = $2 AND status = 'completed'
    `;
    
    const result = await db.query(query, [userId, levelId]);
    return result.rows.length > 0;
  }
}

module.exports = PaymentModel;
