-- ========================================
-- INTERNSHIP MANAGEMENT SYSTEM - DATABASE SCHEMA
-- PostgreSQL Database Design
-- ========================================

-- Drop existing tables (for clean installation)
DROP TABLE IF EXISTS certificate_requests CASCADE;
DROP TABLE IF EXISTS submissions CASCADE;
DROP TABLE IF EXISTS tasks CASCADE;
DROP TABLE IF EXISTS sessions CASCADE;
DROP TABLE IF EXISTS payments CASCADE;
DROP TABLE IF EXISTS student_progress CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS levels CASCADE;

-- ========================================
-- 1. LEVELS TABLE
-- ========================================
CREATE TABLE levels (
    level_id VARCHAR(10) PRIMARY KEY,
    level_name VARCHAR(50) NOT NULL,
    description TEXT,
    total_sessions INTEGER NOT NULL,
    session_duration_hours INTEGER NOT NULL,
    required_pass_sessions INTEGER NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default levels
INSERT INTO levels (level_id, level_name, description, total_sessions, session_duration_hours, required_pass_sessions, price) VALUES
('L3', 'Level 3 - Frontend Basics', 'HTML, CSS, and Web Layout Design', 10, 8, 8, 50000.00),
('L4', 'Level 4 - Backend Development', 'MySQL, PHP, Node.js and Backend Logic', 5, 10, 4, 75000.00),
('L5', 'Level 5 - Full Stack', 'React.js, CRUD Operations, and Full-Stack Development', 3, 48, 3, 100000.00);

-- ========================================
-- 2. USERS TABLE
-- ========================================
CREATE TABLE users (
    user_id SERIAL PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'student',
    school_institution VARCHAR(255),
    phone VARCHAR(20),
    profile_picture VARCHAR(255),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_role CHECK (role IN ('student', 'supervisor', 'admin'))
);

-- Create index for faster email lookup
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);

-- ========================================
-- 3. PAYMENTS TABLE
-- ========================================
CREATE TABLE payments (
    payment_id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    level_id VARCHAR(10) NOT NULL REFERENCES levels(level_id),
    amount DECIMAL(10, 2) NOT NULL,
    payment_method VARCHAR(50),
    transaction_id VARCHAR(100) UNIQUE,
    status VARCHAR(20) DEFAULT 'pending',
    paid_at TIMESTAMP,
    verified_by INTEGER REFERENCES users(user_id),
    verified_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_payment_status CHECK (status IN ('pending', 'completed', 'failed', 'refunded'))
);

CREATE INDEX idx_payments_user ON payments(user_id);
CREATE INDEX idx_payments_status ON payments(status);

-- ========================================
-- 4. STUDENT_PROGRESS TABLE
-- ========================================
CREATE TABLE student_progress (
    progress_id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    level_id VARCHAR(10) NOT NULL REFERENCES levels(level_id),
    payment_id INTEGER REFERENCES payments(payment_id),
    internship_start_date TIMESTAMP,
    internship_end_date TIMESTAMP,
    completed_sessions INTEGER DEFAULT 0,
    failed_sessions INTEGER DEFAULT 0,
    total_score DECIMAL(5, 2) DEFAULT 0.00,
    is_eligible_for_certificate BOOLEAN DEFAULT false,
    certificate_issued BOOLEAN DEFAULT false,
    certificate_issued_date TIMESTAMP,
    status VARCHAR(20) DEFAULT 'not_started',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_progress_status CHECK (status IN ('not_started', 'in_progress', 'completed', 'failed')),
    UNIQUE(user_id, level_id)
);

CREATE INDEX idx_progress_user ON student_progress(user_id);
CREATE INDEX idx_progress_status ON student_progress(status);

-- ========================================
-- 5. SESSIONS TABLE
-- ========================================
CREATE TABLE sessions (
    session_id SERIAL PRIMARY KEY,
    level_id VARCHAR(10) NOT NULL REFERENCES levels(level_id),
    session_number INTEGER NOT NULL,
    session_title VARCHAR(255) NOT NULL,
    description TEXT,
    reading_material_url TEXT,
    reading_material_content TEXT,
    duration_hours INTEGER NOT NULL,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(level_id, session_number)
);

CREATE INDEX idx_sessions_level ON sessions(level_id);

-- ========================================
-- 6. TASKS TABLE
-- ========================================
CREATE TABLE tasks (
    task_id SERIAL PRIMARY KEY,
    session_id INTEGER NOT NULL REFERENCES sessions(session_id) ON DELETE CASCADE,
    task_title VARCHAR(255) NOT NULL,
    task_description TEXT NOT NULL,
    task_requirements TEXT,
    max_score DECIMAL(5, 2) DEFAULT 100.00,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_tasks_session ON tasks(session_id);

-- ========================================
-- 7. SUBMISSIONS TABLE
-- ========================================
CREATE TABLE submissions (
    submission_id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    task_id INTEGER NOT NULL REFERENCES tasks(task_id) ON DELETE CASCADE,
    session_id INTEGER NOT NULL REFERENCES sessions(session_id),
    submission_content TEXT,
    submission_file_url TEXT,
    github_url TEXT,
    demo_url TEXT,
    has_read_material BOOLEAN DEFAULT false,
    material_read_at TIMESTAMP,
    task_unlocked_at TIMESTAMP,
    submitted_at TIMESTAMP,
    deadline TIMESTAMP NOT NULL,
    is_late BOOLEAN DEFAULT false,
    score DECIMAL(5, 2) DEFAULT 0.00,
    feedback TEXT,
    graded_by INTEGER REFERENCES users(user_id),
    graded_at TIMESTAMP,
    status VARCHAR(20) DEFAULT 'not_started',
    recovery_requested BOOLEAN DEFAULT false,
    recovery_reason TEXT,
    recovery_approved BOOLEAN DEFAULT false,
    recovery_approved_by INTEGER REFERENCES users(user_id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_submission_status CHECK (status IN ('not_started', 'reading', 'in_progress', 'submitted', 'graded', 'failed')),
    UNIQUE(user_id, task_id)
);

CREATE INDEX idx_submissions_user ON submissions(user_id);
CREATE INDEX idx_submissions_task ON submissions(task_id);
CREATE INDEX idx_submissions_status ON submissions(status);

-- ========================================
-- 8. CERTIFICATE_REQUESTS TABLE
-- ========================================
CREATE TABLE certificate_requests (
    request_id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    progress_id INTEGER NOT NULL REFERENCES student_progress(progress_id),
    request_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approved BOOLEAN DEFAULT false,
    approved_by INTEGER REFERENCES users(user_id),
    approved_at TIMESTAMP,
    certificate_url TEXT,
    certificate_id VARCHAR(50) UNIQUE,
    rejection_reason TEXT,
    status VARCHAR(20) DEFAULT 'pending',
    CONSTRAINT check_certificate_status CHECK (status IN ('pending', 'approved', 'rejected'))
);

CREATE INDEX idx_certificate_requests_user ON certificate_requests(user_id);

-- ========================================
-- TRIGGERS AND FUNCTIONS
-- ========================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply trigger to relevant tables
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_student_progress_updated_at BEFORE UPDATE ON student_progress
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_submissions_updated_at BEFORE UPDATE ON submissions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to automatically start internship after payment
CREATE OR REPLACE FUNCTION start_internship_after_payment()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
        UPDATE student_progress
        SET 
            internship_start_date = CURRENT_TIMESTAMP,
            status = 'in_progress'
        WHERE user_id = NEW.user_id AND level_id = NEW.level_id;
    END IF;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER trigger_start_internship AFTER UPDATE ON payments
    FOR EACH ROW EXECUTE FUNCTION start_internship_after_payment();

-- Function to check certificate eligibility
CREATE OR REPLACE FUNCTION check_certificate_eligibility()
RETURNS TRIGGER AS $$
DECLARE
    required_sessions INTEGER;
    current_completed INTEGER;
BEGIN
    SELECT required_pass_sessions INTO required_sessions
    FROM levels WHERE level_id = NEW.level_id;
    
    IF NEW.completed_sessions >= required_sessions THEN
        NEW.is_eligible_for_certificate = true;
    ELSE
        NEW.is_eligible_for_certificate = false;
    END IF;
    
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER trigger_check_eligibility BEFORE UPDATE ON student_progress
    FOR EACH ROW EXECUTE FUNCTION check_certificate_eligibility();

-- ========================================
-- VIEWS FOR REPORTING
-- ========================================

-- View for student dashboard
CREATE OR REPLACE VIEW student_dashboard AS
SELECT 
    u.user_id,
    u.first_name,
    u.last_name,
    u.email,
    sp.level_id,
    l.level_name,
    sp.internship_start_date,
    sp.completed_sessions,
    sp.failed_sessions,
    l.total_sessions,
    l.required_pass_sessions,
    sp.total_score,
    sp.is_eligible_for_certificate,
    sp.certificate_issued,
    sp.status as progress_status
FROM users u
JOIN student_progress sp ON u.user_id = sp.user_id
JOIN levels l ON sp.level_id = l.level_id
WHERE u.role = 'student';

-- View for supervisor dashboard
CREATE OR REPLACE VIEW supervisor_overview AS
SELECT 
    l.level_id,
    l.level_name,
    COUNT(DISTINCT sp.user_id) as total_students,
    COUNT(DISTINCT CASE WHEN sp.status = 'in_progress' THEN sp.user_id END) as active_students,
    COUNT(DISTINCT CASE WHEN sp.status = 'completed' THEN sp.user_id END) as completed_students,
    COUNT(DISTINCT CASE WHEN sp.is_eligible_for_certificate THEN sp.user_id END) as eligible_for_certificate,
    AVG(sp.total_score) as average_score
FROM levels l
LEFT JOIN student_progress sp ON l.level_id = sp.level_id
GROUP BY l.level_id, l.level_name;

-- ========================================
-- SAMPLE DATA FOR TESTING
-- ========================================

-- Insert sample supervisor (password: supervisor123)
INSERT INTO users (first_name, last_name, email, password_hash, role) VALUES
('Admin', 'Supervisor', 'supervisor@internship.com', '$2b$10$YourHashedPasswordHere', 'supervisor');

-- Insert sample sessions for L3
INSERT INTO sessions (level_id, session_number, session_title, description, duration_hours) VALUES
('L3', 1, 'HTML Fundamentals', 'Learn the basics of HTML structure and semantic elements', 8),
('L3', 2, 'CSS Styling Basics', 'Introduction to CSS styling, selectors, and box model', 8),
('L3', 3, 'CSS Flexbox Layout', 'Master flexbox for responsive layouts', 8),
('L3', 4, 'CSS Grid System', 'Advanced grid layouts and positioning', 8),
('L3', 5, 'Responsive Design', 'Media queries and mobile-first design', 8),
('L3', 6, 'CSS Animations', 'Transitions and keyframe animations', 8),
('L3', 7, 'Forms and Input Handling', 'Creating accessible forms', 8),
('L3', 8, 'Web Typography', 'Font styling and web fonts', 8),
('L3', 9, 'CSS Best Practices', 'Code organization and naming conventions', 8),
('L3', 10, 'Final Project - Landing Page', 'Build a complete responsive landing page', 8);

-- Insert sample tasks for L3 sessions
INSERT INTO tasks (session_id, task_title, task_description, max_score) 
SELECT session_id, 
    'Practical Task for ' || session_title,
    'Complete the practical exercise for ' || session_title,
    100.00
FROM sessions WHERE level_id = 'L3';

-- Grant permissions
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO postgres;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO postgres;

-- Success message
SELECT 'Database schema created successfully!' as status;
