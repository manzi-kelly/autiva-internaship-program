import React, { useState } from 'react';
import { BookOpen, AlertCircle } from 'lucide-react';
import Button from '../common/Button';

export default function DocumentReader({ session, config, onRead }) {
  const [hasRead, setHasRead] = useState(session.documentRead);

  const handleConfirmRead = () => {
    setHasRead(true);
    onRead();
  };

  return (
    <div className="space-y-6">
      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
        <div className="flex items-start space-x-4 mb-4">
          <BookOpen className={`w-6 h-6 ${config.colorClasses.text}`} />
          <div>
            <h4 className="font-semibold text-white mb-2">Study Material</h4>
            <p className="text-slate-400">
              Carefully read and understand the following material before attempting the practical task. 
              This document contains essential concepts you'll need to successfully complete the assignment.
            </p>
          </div>
        </div>
        
        {/* Simulated Document Content */}
        <div className="bg-slate-900/50 rounded-xl p-6 border border-slate-700 mt-4 space-y-4 text-slate-300 max-h-96 overflow-y-auto">
          <h5 className="font-semibold text-white text-lg">Introduction to {session.title.split(': ')[1]}</h5>
          <p>
            This session will cover fundamental concepts and practical applications. You'll learn key techniques, 
            best practices, and common patterns used in professional development.
          </p>
          <p>
            By the end of this session, you should be able to implement real-world solutions and understand 
            the underlying principles that make your code efficient and maintainable.
          </p>
          <div className={`${config.colorClasses.bgLight} rounded-lg p-4 border-l-4 ${config.colorClasses.border}`}>
            <p className={`text-sm font-medium ${config.colorClasses.text}`}>💡 Pro Tip</p>
            <p className="text-sm mt-1">Take notes as you read. You'll need this knowledge for the practical task ahead.</p>
          </div>
          <h5 className="font-semibold text-white pt-4">Key Concepts</h5>
          <ul className="list-disc list-inside space-y-2">
            <li>Understanding core principles and fundamentals</li>
            <li>Applying best practices in real-world scenarios</li>
            <li>Common patterns and anti-patterns to avoid</li>
            <li>Performance considerations and optimization</li>
          </ul>
        </div>
      </div>

      <div className="flex items-start space-x-3 bg-amber-500/10 border border-amber-500/30 rounded-xl p-4">
        <AlertCircle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
        <div className="text-sm text-amber-200">
          You must confirm that you've read and understood this material before the task becomes available.
          Please review carefully as the task will require this knowledge.
        </div>
      </div>

      <Button
        onClick={handleConfirmRead}
        disabled={hasRead}
        variant={hasRead ? 'secondary' : 'success'}
        fullWidth
      >
        {hasRead ? 'Document Reviewed ✓' : 'I Have Read & Understood'}
      </Button>
    </div>
  );
}
