/**
 * Supervisor Service
 * Handles all supervisor-related API calls
 */

import { get, post } from '../utils/api';
import { API_ENDPOINTS } from '../constants/apiConfig';

export const supervisorService = {
  /**
   * Get all students
   */
  async getAllStudents() {
    return await get(API_ENDPOINTS.GET_ALL_STUDENTS);
  },

  /**
   * Get student details
   */
  async getStudentDetails(studentId) {
    return await get(
      API_ENDPOINTS.GET_STUDENT_DETAILS.replace(':id', studentId)
    );
  },

  /**
   * Approve recovery request
   */
  async approveRecovery(studentId, sessionId) {
    return await post(
      API_ENDPOINTS.APPROVE_RECOVERY.replace(':id', studentId),
      { sessionId }
    );
  },

  /**
   * Extend deadline
   */
  async extendDeadline(studentId, sessionId, hours) {
    return await post(
      API_ENDPOINTS.EXTEND_DEADLINE.replace(':id', studentId),
      { sessionId, hours }
    );
  },

  /**
   * Reopen session
   */
  async reopenSession(studentId, sessionId) {
    return await post(
      API_ENDPOINTS.REOPEN_SESSION
        .replace(':id', studentId)
        .replace(':sessionId', sessionId)
    );
  },

  /**
   * Approve certificate
   */
  async approveCertificate(studentId) {
    return await post(
      API_ENDPOINTS.APPROVE_CERTIFICATE.replace(':id', studentId)
    );
  },

  /**
   * Grade submission
   */
  async gradeSubmission(studentId, sessionId, score, feedback) {
    return await post(`/supervisor/students/${studentId}/sessions/${sessionId}/grade`, {
      score,
      feedback
    });
  }
};
