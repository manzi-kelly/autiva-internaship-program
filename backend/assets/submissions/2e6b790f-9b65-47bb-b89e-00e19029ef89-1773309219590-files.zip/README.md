# Internship Management System

A comprehensive full-stack web application for managing student internships with automatic session tracking, task submissions, payment verification, and certificate generation.

## 🚀 Features

### For Students
- **User Registration & Authentication**: Secure JWT-based authentication
- **Level Selection**: Choose from L3 (Frontend), L4 (Backend), or L5 (Full-Stack)
- **Payment Processing**: Submit payment and await verification
- **Session Management**: Access reading materials and unlock tasks
- **Task Submission**: Submit tasks within deadlines with GitHub/demo links
- **Progress Tracking**: Real-time tracking of completed/failed sessions
- **Recovery Requests**: Request deadline extensions with supervisor approval
- **Certificate Eligibility**: Automatic eligibility calculation

### For Supervisors
- **Payment Verification**: Approve student payments to activate internships
- **Student Oversight**: Monitor all student progress and submissions
- **Grading System**: Grade student submissions with feedback
- **Recovery Management**: Approve/reject recovery requests
- **Analytics Dashboard**: View statistics and student performance

## 🏗️ Architecture

### Technology Stack
- **Frontend**: React 18 + Tailwind CSS (via CDN)
- **Backend**: Node.js + Express
- **Database**: PostgreSQL
- **Authentication**: JWT (JSON Web Tokens)
- **API**: RESTful API architecture

### Project Structure
```
internship-system/
├── backend/
│   ├── config/
│   │   └── database.js          # PostgreSQL connection pool
│   ├── controllers/
│   │   ├── authController.js    # Authentication logic
│   │   ├── studentController.js # Student operations
│   │   └── supervisorController.js # Supervisor operations
│   ├── middleware/
│   │   ├── auth.js              # JWT verification & authorization
│   │   └── errorHandler.js      # Centralized error handling
│   ├── models/
│   │   ├── User.js              # User database operations
│   │   ├── Level.js             # Level/course management
│   │   ├── Payment.js           # Payment processing
│   │   └── Submission.js        # Task submissions & grading
│   ├── routes/
│   │   ├── auth.js              # Auth routes
│   │   ├── student.js           # Student routes
│   │   ├── supervisor.js        # Supervisor routes
│   │   └── levels.js            # Public level info
│   ├── server.js                # Main server file
│   ├── package.json             # Dependencies
│   └── .env.example             # Environment variables template
├── database/
│   └── schema.sql               # PostgreSQL database schema
└── frontend/
    └── index.html               # React SPA with Tailwind CSS
```

## 📦 Installation & Setup

### Prerequisites
- Node.js (v14 or higher)
- PostgreSQL (v12 or higher)
- npm or yarn

### 1. Database Setup

```bash
# Create database
createdb internship_system

# Run schema
psql -d internship_system -f database/schema.sql
```

### 2. Backend Setup

```bash
cd backend

# Install dependencies
npm install

# Create .env file
cp .env.example .env

# Edit .env with your configuration
nano .env
```

**Environment Variables (.env):**
```env
PORT=5000
NODE_ENV=development

DB_HOST=localhost
DB_PORT=5432
DB_NAME=internship_system
DB_USER=postgres
DB_PASSWORD=your_password

JWT_SECRET=your_secret_key_change_in_production
JWT_EXPIRE=7d

CORS_ORIGIN=http://localhost:3000
```

```bash
# Start backend server
npm start

# Or use nodemon for development
npm run dev
```

Backend will run on `http://localhost:5000`

### 3. Frontend Setup

```bash
cd frontend

# No build step required - just open in browser
# Serve with any static server, for example:
python3 -m http.server 3000

# Or use VS Code Live Server
# Or simply open index.html in browser
```

Frontend will be available at `http://localhost:3000`

## 📚 API Documentation

### Base URL
```
http://localhost:5000/api
```

### Authentication Endpoints

#### Register
```http
POST /api/auth/register
Content-Type: application/json

{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "password": "password123",
  "school": "University Name"
}
```

#### Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "password123"
}
```

#### Get Profile
```http
GET /api/auth/profile
Authorization: Bearer <token>
```

### Student Endpoints

#### Get Dashboard
```http
GET /api/student/dashboard
Authorization: Bearer <token>
```

#### Enroll in Level
```http
POST /api/student/enroll
Authorization: Bearer <token>
Content-Type: application/json

{
  "levelId": "L3",
  "paymentMethod": "bank_transfer"
}
```

#### Mark Material as Read
```http
POST /api/student/tasks/:taskId/read
Authorization: Bearer <token>
```

#### Submit Task
```http
POST /api/student/tasks/:taskId/submit
Authorization: Bearer <token>
Content-Type: application/json

{
  "content": "Task description",
  "githubUrl": "https://github.com/...",
  "demoUrl": "https://demo.com"
}
```

#### Request Recovery
```http
POST /api/student/tasks/:taskId/recovery
Authorization: Bearer <token>
Content-Type: application/json

{
  "reason": "Family emergency prevented submission"
}
```

### Supervisor Endpoints

#### Get Dashboard
```http
GET /api/supervisor/dashboard
Authorization: Bearer <token>
```

#### Verify Payment
```http
POST /api/supervisor/payments/:paymentId/verify
Authorization: Bearer <token>
```

#### Grade Submission
```http
POST /api/supervisor/submissions/:submissionId/grade
Authorization: Bearer <token>
Content-Type: application/json

{
  "score": 85,
  "feedback": "Great work! Consider improving..."
}
```

#### Approve Recovery
```http
POST /api/supervisor/recoveries/:submissionId/approve
Authorization: Bearer <token>
Content-Type: application/json

{
  "extensionHours": 24
}
```

### Public Endpoints

#### Get All Levels
```http
GET /api/levels
```

#### Get Level Details
```http
GET /api/levels/:levelId
```

## 🗄️ Database Schema

### Key Tables

**users**: Store user accounts (students, supervisors)
**levels**: Define internship levels (L3, L4, L5)
**sessions**: Course sessions within each level
**tasks**: Practical tasks for each session
**submissions**: Student task submissions
**payments**: Payment records and verification
**student_progress**: Track overall student progress
**certificate_requests**: Certificate generation requests

### Automated Triggers

- **Auto-start internship**: Automatically starts internship when payment is verified
- **Deadline enforcement**: Auto-fail submissions past deadline
- **Certificate eligibility**: Auto-calculate based on completed sessions
- **Progress tracking**: Auto-update progress on task grading

## 🔐 Security Features

- JWT-based authentication
- Password hashing with bcrypt
- Role-based access control (RBAC)
- SQL injection prevention (parameterized queries)
- CORS configuration
- Helmet security headers
- Input validation

## 🎯 Business Logic

### Internship Flow
1. Student registers and selects level
2. Payment submission (pending state)
3. Supervisor verifies payment
4. Internship automatically starts
5. Sessions become available
6. Student reads material → unlocks task
7. Task submission within deadline
8. Supervisor grades submission
9. Progress tracked automatically
10. Certificate generated if eligible

### Deadline Rules
- **L3**: 8 hours per session
- **L4**: 10 hours per session
- **L5**: 48 hours per project
- Late submissions = automatic 0 score
- Recovery requests available with supervisor approval

### Certificate Requirements
- **L3**: Complete 8 out of 10 sessions
- **L4**: Complete 4 out of 5 sessions
- **L5**: Complete all 3 projects

## 🎨 Frontend Features

### Design
- Modern gradient background with animated blobs
- Glass-morphism effects
- Smooth transitions and animations
- Responsive design for all screen sizes
- Professional typography (Sora + Manrope fonts)

### User Experience
- Single Page Application (SPA)
- Real-time updates
- Loading states
- Error handling with user-friendly messages
- Intuitive navigation
- Progress visualization

## 🔧 Development

### Adding New Levels
1. Insert into `levels` table
2. Create sessions in `sessions` table
3. Create tasks for each session

### Creating Sample Users
```sql
-- Create supervisor
INSERT INTO users (first_name, last_name, email, password_hash, role)
VALUES ('Admin', 'Supervisor', 'admin@internship.com', '$2b$10$hashedpassword', 'supervisor');

-- Note: Use bcrypt to hash passwords programmatically
```

### Testing
```bash
# Test database connection
psql -d internship_system -c "SELECT NOW();"

# Test API health
curl http://localhost:5000/api/health

# Test authentication
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"password"}'
```

## 🐛 Debugging

### Common Issues

**Database Connection Failed**
- Check PostgreSQL is running: `sudo service postgresql status`
- Verify credentials in `.env`
- Ensure database exists

**CORS Errors**
- Check `CORS_ORIGIN` in `.env` matches frontend URL
- Verify backend is running

**JWT Token Expired**
- Re-login to get new token
- Check `JWT_EXPIRE` setting

**Port Already in Use**
- Change `PORT` in `.env`
- Kill process: `lsof -ti:5000 | xargs kill`

## 📈 Future Enhancements

- [ ] Email notifications
- [ ] File upload for submissions
- [ ] Real-time chat/support
- [ ] Certificate PDF generation
- [ ] Payment gateway integration
- [ ] Mobile app (React Native)
- [ ] Advanced analytics dashboard
- [ ] Plagiarism detection
- [ ] Video lesson integration
- [ ] Automated testing system

## 👥 Default Credentials

After running the schema, create a supervisor account:

**Email**: supervisor@internship.com  
**Password**: (set during user creation)

Students can register through the UI.

## 📄 License

MIT License - Feel free to use for educational purposes

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## 📞 Support

For issues or questions:
- Create an issue in the repository
- Email: support@internship.com

---

**Built with ❤️ for better internship management**
