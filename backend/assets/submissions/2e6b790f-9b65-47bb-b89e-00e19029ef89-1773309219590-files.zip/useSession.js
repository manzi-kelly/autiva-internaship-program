import { useState, useCallback } from 'react';
import { post, uploadFile } from '../utils/api';
import { API_ENDPOINTS } from '../constants/apiConfig';

export function useSession() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const markDocumentAsRead = useCallback(async (sessionId) => {
    setLoading(true);
    setError(null);
    
    try {
      const result = await post(
        API_ENDPOINTS.READ_DOCUMENT.replace(':id', sessionId)
      );
      
      if (result.success) {
        return { success: true, data: result.data };
      } else {
        setError(result.error);
        return { success: false, error: result.error };
      }
    } catch (err) {
      setError(err.message);
      return { success: false, error: err.message };
    } finally {
      setLoading(false);
    }
  }, []);

  const submitTask = useCallback(async (sessionId, file) => {
    setLoading(true);
    setError(null);
    
    try {
      const result = await uploadFile(
        API_ENDPOINTS.SUBMIT_TASK.replace(':id', sessionId),
        file
      );
      
      if (result.success) {
        return { success: true, data: result.data };
      } else {
        setError(result.error);
        return { success: false, error: result.error };
      }
    } catch (err) {
      setError(err.message);
      return { success: false, error: err.message };
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    loading,
    error,
    markDocumentAsRead,
    submitTask,
  };
}
