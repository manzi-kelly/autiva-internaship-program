/**
 * Supervisor Controller
 * Handles supervisor/admin operations like payment verification, grading, and oversight
 */

const UserModel = require('../models/User');
const PaymentModel = require('../models/Payment');
const SubmissionModel = require('../models/Submission');
const { AppError } = require('../middleware/errorHandler');

class SupervisorController {
  /**
   * Get supervisor dashboard overview
   */
  static async getDashboard(req, res, next) {
    try {
      // Get all students
      const students = await UserModel.getAllStudents();

      // Get pending payments
      const pendingPayments = await PaymentModel.getPendingPayments();

      // Get pending recoveries
      const pendingRecoveries = await SubmissionModel.getPendingRecoveries();

      res.json({
        success: true,
        data: {
          students,
          pendingPayments,
          pendingRecoveries,
          stats: {
            totalStudents: students.length,
            activeStudents: students.filter(s => s.progress_status === 'in_progress').length,
            pendingPayments: pendingPayments.length,
            pendingRecoveries: pendingRecoveries.length
          }
        }
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Get all students
   */
  static async getAllStudents(req, res, next) {
    try {
      const students = await UserModel.getAllStudents();

      res.json({
        success: true,
        data: { students }
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Verify payment
   */
  static async verifyPayment(req, res, next) {
    try {
      const supervisorId = req.user.userId;
      const { paymentId } = req.params;

      const payment = await PaymentModel.verifyPayment(parseInt(paymentId), supervisorId);

      res.json({
        success: true,
        message: 'Payment verified successfully. Internship activated!',
        data: { payment }
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Get pending payments
   */
  static async getPendingPayments(req, res, next) {
    try {
      const payments = await PaymentModel.getPendingPayments();

      res.json({
        success: true,
        data: { payments }
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Grade a submission
   */
  static async gradeSubmission(req, res, next) {
    try {
      const supervisorId = req.user.userId;
      const { submissionId } = req.params;
      const { score, feedback } = req.body;

      // Validate score
      if (score === undefined || score < 0 || score > 100) {
        throw new AppError('Score must be between 0 and 100', 400);
      }

      const submission = await SubmissionModel.gradeSubmission(
        parseInt(submissionId),
        score,
        feedback || '',
        supervisorId
      );

      res.json({
        success: true,
        message: 'Submission graded successfully',
        data: { submission }
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Get pending recovery requests
   */
  static async getPendingRecoveries(req, res, next) {
    try {
      const recoveries = await SubmissionModel.getPendingRecoveries();

      res.json({
        success: true,
        data: { recoveries }
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Approve recovery request
   */
  static async approveRecovery(req, res, next) {
    try {
      const supervisorId = req.user.userId;
      const { submissionId } = req.params;
      const { extensionHours = 24 } = req.body;

      const submission = await SubmissionModel.approveRecovery(
        parseInt(submissionId),
        supervisorId,
        extensionHours
      );

      res.json({
        success: true,
        message: 'Recovery approved. Deadline extended.',
        data: { submission }
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Get submission details
   */
  static async getSubmissionDetails(req, res, next) {
    try {
      const { submissionId } = req.params;

      const submission = await SubmissionModel.getById(parseInt(submissionId));

      if (!submission) {
        throw new AppError('Submission not found', 404);
      }

      res.json({
        success: true,
        data: { submission }
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Get student details with all progress
   */
  static async getStudentDetails(req, res, next) {
    try {
      const { userId } = req.params;

      const user = await UserModel.findById(parseInt(userId));
      if (!user) {
        throw new AppError('Student not found', 404);
      }

      const submissions = await SubmissionModel.getUserSubmissions(parseInt(userId));
      const payments = await PaymentModel.getUserPayments(parseInt(userId));

      res.json({
        success: true,
        data: {
          user,
          submissions,
          payments
        }
      });
    } catch (error) {
      next(error);
    }
  }
}

module.exports = SupervisorController;
