# API Testing Examples

Collection of curl commands to test all API endpoints.

## Setup

```bash
# Set your base URL
export API_URL="http://localhost:5000/api"

# After login, set your token
export TOKEN="your_jwt_token_here"
```

## Authentication

### Register Student
```bash
curl -X POST $API_URL/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "John",
    "lastName": "Doe",
    "email": "john@example.com",
    "password": "password123",
    "school": "Tech University"
  }'
```

### Login
```bash
curl -X POST $API_URL/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john@example.com",
    "password": "password123"
  }'

# Save the token from response:
# export TOKEN="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

### Get Profile
```bash
curl -X GET $API_URL/auth/profile \
  -H "Authorization: Bearer $TOKEN"
```

### Update Profile
```bash
curl -X PUT $API_URL/auth/profile \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "John",
    "lastName": "Smith",
    "phone": "+1234567890"
  }'
```

## Public Endpoints

### Get All Levels
```bash
curl -X GET $API_URL/levels
```

### Get Level Details
```bash
curl -X GET $API_URL/levels/L3
```

## Student Endpoints

### Get Dashboard
```bash
curl -X GET $API_URL/student/dashboard \
  -H "Authorization: Bearer $TOKEN"
```

### Enroll in Level
```bash
curl -X POST $API_URL/student/enroll \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "levelId": "L3",
    "paymentMethod": "bank_transfer"
  }'
```

### Get Level Details
```bash
curl -X GET $API_URL/student/levels/L3 \
  -H "Authorization: Bearer $TOKEN"
```

### Mark Material as Read
```bash
curl -X POST $API_URL/student/tasks/1/read \
  -H "Authorization: Bearer $TOKEN"
```

### Submit Task
```bash
curl -X POST $API_URL/student/tasks/1/submit \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "content": "Completed the HTML fundamentals task",
    "githubUrl": "https://github.com/johndoe/html-task",
    "demoUrl": "https://johndoe.github.io/html-task"
  }'
```

### Get My Submissions
```bash
curl -X GET $API_URL/student/submissions \
  -H "Authorization: Bearer $TOKEN"

# Filter by level
curl -X GET "$API_URL/student/submissions?levelId=L3" \
  -H "Authorization: Bearer $TOKEN"
```

### Request Recovery
```bash
curl -X POST $API_URL/student/tasks/1/recovery \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "reason": "Family emergency prevented me from submitting on time"
  }'
```

## Supervisor Endpoints

### Get Supervisor Dashboard
```bash
curl -X GET $API_URL/supervisor/dashboard \
  -H "Authorization: Bearer $TOKEN"
```

### Get All Students
```bash
curl -X GET $API_URL/supervisor/students \
  -H "Authorization: Bearer $TOKEN"
```

### Get Student Details
```bash
curl -X GET $API_URL/supervisor/students/1 \
  -H "Authorization: Bearer $TOKEN"
```

### Get Pending Payments
```bash
curl -X GET $API_URL/supervisor/payments/pending \
  -H "Authorization: Bearer $TOKEN"
```

### Verify Payment
```bash
curl -X POST $API_URL/supervisor/payments/1/verify \
  -H "Authorization: Bearer $TOKEN"
```

### Get Submission Details
```bash
curl -X GET $API_URL/supervisor/submissions/1 \
  -H "Authorization: Bearer $TOKEN"
```

### Grade Submission
```bash
curl -X POST $API_URL/supervisor/submissions/1/grade \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "score": 85,
    "feedback": "Great work! Your HTML structure is clean. Consider adding more semantic elements."
  }'
```

### Get Pending Recoveries
```bash
curl -X GET $API_URL/supervisor/recoveries/pending \
  -H "Authorization: Bearer $TOKEN"
```

### Approve Recovery
```bash
curl -X POST $API_URL/supervisor/recoveries/1/approve \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "extensionHours": 24
  }'
```

## Health Check

```bash
curl -X GET $API_URL/health
```

## Testing Workflow

### Complete Student Flow
```bash
# 1. Register
curl -X POST $API_URL/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "Test",
    "lastName": "Student",
    "email": "test@example.com",
    "password": "test123",
    "school": "Test School"
  }'

# 2. Login (save token)
TOKEN=$(curl -s -X POST $API_URL/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "test123"
  }' | jq -r '.data.token')

echo "Token: $TOKEN"

# 3. View levels
curl -X GET $API_URL/levels

# 4. Enroll
curl -X POST $API_URL/student/enroll \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"levelId": "L3", "paymentMethod": "bank_transfer"}'

# 5. Check dashboard
curl -X GET $API_URL/student/dashboard \
  -H "Authorization: Bearer $TOKEN"
```

### Complete Supervisor Flow
```bash
# 1. Login as supervisor
SUPERVISOR_TOKEN=$(curl -s -X POST $API_URL/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "supervisor@test.com",
    "password": "password123"
  }' | jq -r '.data.token')

# 2. Get pending payments
curl -X GET $API_URL/supervisor/payments/pending \
  -H "Authorization: Bearer $SUPERVISOR_TOKEN"

# 3. Verify payment (use actual payment ID from step 2)
curl -X POST $API_URL/supervisor/payments/1/verify \
  -H "Authorization: Bearer $SUPERVISOR_TOKEN"

# 4. View all students
curl -X GET $API_URL/supervisor/students \
  -H "Authorization: Bearer $SUPERVISOR_TOKEN"
```

## Response Examples

### Successful Login Response
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": {
      "id": 1,
      "firstName": "John",
      "lastName": "Doe",
      "email": "john@example.com",
      "role": "student"
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

### Error Response
```json
{
  "success": false,
  "message": "Invalid credentials"
}
```

### Dashboard Response
```json
{
  "success": true,
  "data": {
    "levels": [...],
    "payments": [...],
    "activeProgress": [...]
  }
}
```

## Tips

1. **Use jq for JSON parsing**
   ```bash
   curl ... | jq .
   ```

2. **Save responses to file**
   ```bash
   curl ... > response.json
   ```

3. **Include headers in response**
   ```bash
   curl -i ...
   ```

4. **Verbose output for debugging**
   ```bash
   curl -v ...
   ```

5. **Test with Postman**
   - Import these curl commands into Postman
   - Create environment variables for API_URL and TOKEN
   - Use collection runner for automated testing

## Automated Testing Script

```bash
#!/bin/bash

# Test all endpoints
echo "Testing Health..."
curl -s $API_URL/health | jq .

echo "Testing Registration..."
curl -s -X POST $API_URL/auth/register \
  -H "Content-Type: application/json" \
  -d '{"firstName":"Test","lastName":"User","email":"test@test.com","password":"test123","school":"Test"}' \
  | jq .

echo "Testing Login..."
curl -s -X POST $API_URL/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"test123"}' \
  | jq .

echo "Testing Levels..."
curl -s $API_URL/levels | jq .

echo "All tests completed!"
```

Save as `test-api.sh`, make executable with `chmod +x test-api.sh`, and run with `./test-api.sh`
