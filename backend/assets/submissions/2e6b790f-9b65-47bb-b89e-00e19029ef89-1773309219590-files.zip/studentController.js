/**
 * Student Controller
 * Handles student-specific operations like dashboard, tasks, and submissions
 */

const LevelModel = require('../models/Level');
const PaymentModel = require('../models/Payment');
const SubmissionModel = require('../models/Submission');
const { AppError } = require('../middleware/errorHandler');

class StudentController {
  /**
   * Get student dashboard data
   */
  static async getDashboard(req, res, next) {
    try {
      const userId = req.user.userId;

      // Get levels
      const levels = await LevelModel.getAll();

      // Get payments
      const payments = await PaymentModel.getUserPayments(userId);

      // Get active progress (if any)
      const activeProgress = [];
      for (const payment of payments) {
        if (payment.status === 'completed') {
          const progress = await LevelModel.getStudentProgress(userId, payment.level_id);
          if (progress) {
            activeProgress.push(progress);
          }
        }
      }

      res.json({
        success: true,
        data: {
          levels,
          payments,
          activeProgress
        }
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Enroll in a level (create payment)
   */
  static async enrollInLevel(req, res, next) {
    try {
      const userId = req.user.userId;
      const { levelId, paymentMethod } = req.body;

      // Validate level
      const level = await LevelModel.getById(levelId);
      if (!level) {
        throw new AppError('Level not found', 404);
      }

      // Check if already enrolled
      const hasPayment = await PaymentModel.hasActivePayment(userId, levelId);
      if (hasPayment) {
        throw new AppError('Already enrolled in this level', 409);
      }

      // Create payment
      const payment = await PaymentModel.create({
        userId,
        levelId,
        amount: level.price,
        paymentMethod: paymentMethod || 'bank_transfer'
      });

      res.status(201).json({
        success: true,
        message: 'Enrollment initiated. Awaiting payment verification.',
        data: { payment }
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Get level details with sessions and user progress
   */
  static async getLevelDetails(req, res, next) {
    try {
      const userId = req.user.userId;
      const { levelId } = req.params;

      // Get level with sessions
      const level = await LevelModel.getWithSessions(levelId);
      if (!level) {
        throw new AppError('Level not found', 404);
      }

      // Get user progress
      const progress = await LevelModel.getStudentProgress(userId, levelId);

      // Get user submissions
      const submissions = await SubmissionModel.getUserSubmissions(userId, levelId);

      res.json({
        success: true,
        data: {
          level,
          progress,
          submissions
        }
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Mark reading material as read
   */
  static async markMaterialRead(req, res, next) {
    try {
      const userId = req.user.userId;
      const { taskId } = req.params;

      const submission = await SubmissionModel.markMaterialRead(userId, parseInt(taskId));

      if (!submission) {
        throw new AppError('Submission not found', 404);
      }

      res.json({
        success: true,
        message: 'Material marked as read. Task unlocked!',
        data: { submission }
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Submit a task
   */
  static async submitTask(req, res, next) {
    try {
      const userId = req.user.userId;
      const { taskId } = req.params;
      const { content, fileUrl, githubUrl, demoUrl } = req.body;

      const submission = await SubmissionModel.submitTask(userId, parseInt(taskId), {
        content,
        fileUrl,
        githubUrl,
        demoUrl
      });

      if (!submission) {
        throw new AppError('Submission not found', 404);
      }

      res.json({
        success: true,
        message: 'Task submitted successfully',
        data: { submission }
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Request recovery for failed submission
   */
  static async requestRecovery(req, res, next) {
    try {
      const userId = req.user.userId;
      const { taskId } = req.params;
      const { reason } = req.body;

      if (!reason) {
        throw new AppError('Please provide a reason for recovery', 400);
      }

      const submission = await SubmissionModel.requestRecovery(userId, parseInt(taskId), reason);

      if (!submission) {
        throw new AppError('Submission not found', 404);
      }

      res.json({
        success: true,
        message: 'Recovery request submitted. Awaiting supervisor approval.',
        data: { submission }
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Get all submissions for current user
   */
  static async getMySubmissions(req, res, next) {
    try {
      const userId = req.user.userId;
      const { levelId } = req.query;

      const submissions = await SubmissionModel.getUserSubmissions(userId, levelId);

      res.json({
        success: true,
        data: { submissions }
      });
    } catch (error) {
      next(error);
    }
  }
}

module.exports = StudentController;
