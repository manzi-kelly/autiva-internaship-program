import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export default function RegisterPage() {
  const [formData, setFormData] = useState({
    firstName: '', lastName: '', email: '', password: '', school: '', level: 'L3'
  });
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const result = await register(formData);
    if (result.success) navigate('/payment');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900 p-4">
      <div className="w-full max-w-2xl bg-slate-900/50 backdrop-blur-xl rounded-3xl p-8 border border-slate-800">
        <h2 className="text-3xl font-bold text-white mb-6">Start Your Journey</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <input type="text" placeholder="First Name" value={formData.firstName}
              onChange={(e) => setFormData({...formData, firstName: e.target.value})}
              className="px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white" required />
            <input type="text" placeholder="Last Name" value={formData.lastName}
              onChange={(e) => setFormData({...formData, lastName: e.target.value})}
              className="px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white" required />
          </div>
          <input type="text" placeholder="School/Institution" value={formData.school}
            onChange={(e) => setFormData({...formData, school: e.target.value})}
            className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white" required />
          <input type="email" placeholder="Email" value={formData.email}
            onChange={(e) => setFormData({...formData, email: e.target.value})}
            className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white" required />
          <input type="password" placeholder="Password" value={formData.password}
            onChange={(e) => setFormData({...formData, password: e.target.value})}
            className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white" required />
          <div>
            <label className="block text-sm text-slate-400 mb-2">Select Level</label>
            <div className="grid grid-cols-3 gap-3">
              {['L3', 'L4', 'L5'].map(level => (
                <button key={level} type="button" onClick={() => setFormData({...formData, level})}
                  className={`px-4 py-3 rounded-xl font-semibold ${formData.level === level ? 'bg-emerald-500 text-white' : 'bg-slate-800/50 text-slate-400'}`}>
                  {level}
                </button>
              ))}
            </div>
          </div>
          <button type="submit" className="w-full py-4 bg-gradient-to-r from-emerald-500 to-amber-500 rounded-xl font-semibold text-white">
            Continue to Payment
          </button>
        </form>
        <p className="mt-6 text-center text-slate-400">
          Already have an account? <a href="/login" className="text-emerald-400 hover:underline">Sign In</a>
        </p>
      </div>
    </div>
  );
}
