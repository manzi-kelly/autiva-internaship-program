import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Award } from 'lucide-react';

export default function PaymentPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900 p-4">
      <div className="w-full max-w-2xl bg-slate-900/50 backdrop-blur-xl rounded-3xl p-8 border border-slate-800">
        <div className="text-center mb-8">
          <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-emerald-500 to-amber-500 flex items-center justify-center">
            <Award className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-3xl font-bold text-white mb-2">Complete Registration</h2>
          <p className="text-slate-400">Secure payment to activate your internship</p>
        </div>
        <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700 mb-6">
          <div className="flex justify-between items-center">
            <span className="text-slate-300">Registration Fee</span>
            <span className="text-2xl font-bold text-white">$299</span>
          </div>
        </div>
        <button onClick={() => navigate('/dashboard')}
          className="w-full py-4 bg-gradient-to-r from-emerald-500 to-amber-500 rounded-xl font-semibold text-white">
          Complete Payment
        </button>
      </div>
    </div>
  );
}
