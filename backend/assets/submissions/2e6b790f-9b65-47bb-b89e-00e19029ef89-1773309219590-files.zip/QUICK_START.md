# 🚀 Quick Start Guide

Get the Internship Management System running in 5 minutes!

## Step 1: Database Setup (2 minutes)

```bash
# Create database
createdb internship_system

# Import schema
cd database
psql -d internship_system -f schema.sql
```

You should see: "Database schema created successfully!"

## Step 2: Backend Setup (1 minute)

```bash
cd backend

# Install dependencies (first time only)
npm install

# Create environment file
cp .env.example .env

# Edit .env file - CHANGE THESE VALUES:
# DB_PASSWORD=your_postgres_password
# JWT_SECRET=your_random_secret_key_at_least_32_characters

# Start server
npm start
```

✅ Backend running at `http://localhost:5000`

## Step 3: Frontend Setup (30 seconds)

```bash
cd frontend

# Option 1: Python simple server
python3 -m http.server 3000

# Option 2: VS Code Live Server
# Right-click index.html → "Open with Live Server"

# Option 3: Just open in browser
# Double-click index.html
```

✅ Frontend running at `http://localhost:3000`

## Step 4: Create First Supervisor Account

```bash
# Connect to database
psql -d internship_system

# Create supervisor (change password hash)
INSERT INTO users (first_name, last_name, email, password_hash, role)
VALUES ('Admin', 'Supervisor', 'supervisor@test.com', 
        '$2b$10$rBV2kTkRQ7K6LkXfx5HiOO3HEBZcEPZJQQxJzJDCqx7nPqXbGxH7K', 
        'supervisor');

# Exit psql
\q
```

**Test Credentials:**
- Supervisor: `supervisor@test.com` / `password123`

## Step 5: Test the System

1. Open `http://localhost:3000`
2. Click "Register" and create a student account
3. Login as student
4. Browse levels and enroll in one
5. Logout and login as supervisor (`supervisor@test.com`)
6. Verify the student's payment
7. Logout and login back as student
8. Access your level and start learning!

## 🎉 You're All Set!

### Common Commands

**Start Backend**
```bash
cd backend && npm start
```

**Start Frontend**
```bash
cd frontend && python3 -m http.server 3000
```

**View Logs**
```bash
# Backend logs appear in terminal
# Check for errors or API calls
```

**Reset Database**
```bash
dropdb internship_system
createdb internship_system
psql -d internship_system -f database/schema.sql
```

## 🔧 Troubleshooting

### Backend won't start
```bash
# Check if PostgreSQL is running
sudo service postgresql status

# Check if port 5000 is free
lsof -ti:5000

# Kill process on port 5000
lsof -ti:5000 | xargs kill
```

### Can't connect to database
```bash
# Test connection
psql -d internship_system -c "SELECT NOW();"

# Check .env file has correct credentials
cat backend/.env
```

### Frontend can't reach backend
- Check backend is running on port 5000
- Check CORS_ORIGIN in backend/.env matches frontend URL
- Open browser console (F12) to see error messages

## 📝 Quick Test Checklist

- [ ] Database created and schema loaded
- [ ] Backend running without errors
- [ ] Frontend accessible in browser
- [ ] Can register new student
- [ ] Can login as student
- [ ] Can login as supervisor
- [ ] Student can enroll in level
- [ ] Supervisor can verify payment

## 🎯 Next Steps

1. Read full README.md for detailed documentation
2. Customize levels in database
3. Add more sessions and tasks
4. Configure email notifications
5. Deploy to production server

## 💡 Pro Tips

- Use nodemon for auto-restart during development: `npm run dev`
- Keep backend terminal open to see API logs
- Use browser DevTools to debug frontend issues
- Check database with: `psql -d internship_system`
- Create database backups: `pg_dump internship_system > backup.sql`

## 🆘 Need Help?

Check the full README.md for:
- Complete API documentation
- Database schema details
- Security features
- Architecture overview
- Deployment guide

---

**Happy coding! 🚀**
