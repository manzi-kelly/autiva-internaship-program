# 🚀 Quick Start Examples

## 1. Using Components in Pages

### Example: Enhanced Student Dashboard

```jsx
// src/pages/StudentDashboard.jsx
import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { 
  StatCard, ProgressBar, LevelInfo, 
  SessionCard, SessionModal, Button 
} from '../components';
import { Calendar, CheckCircle, TrendingUp, Award } from 'lucide-react';
import { useSession, useNotification } from '../hooks';
import { LEVEL_CONFIG } from '../constants/levelConfig';

export default function StudentDashboard() {
  const { user } = useAuth();
  const [selectedSession, setSelectedSession] = useState(null);
  const { markDocumentAsRead, submitTask } = useSession();
  const notify = useNotification();
  
  const config = LEVEL_CONFIG[user.level];
  const mockSessions = [/* session data */];

  const handleDocumentRead = async (sessionId) => {
    const result = await markDocumentAsRead(sessionId);
    if (result.success) {
      notify.success('Document marked as read!');
    }
  };

  const handleTaskSubmit = async (sessionId, file) => {
    const result = await submitTask(sessionId, file);
    if (result.success) {
      notify.success('Task submitted successfully!');
      setSelectedSession(null);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900">
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats Grid */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <StatCard icon={Calendar} label="Days Active" value="15" color="emerald" />
          <StatCard icon={CheckCircle} label="Completed" value="2/10" color="emerald" />
          <StatCard icon={TrendingUp} label="Progress" value="20%" color="amber" />
          <StatCard icon={Award} label="Certificate" value="Pending" color="rose" />
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <ProgressBar progress={20} color={config.color} label="Overall Progress" />
        </div>

        {/* Level Info */}
        <LevelInfo level={user.level} />

        {/* Sessions */}
        <div className="mt-8 space-y-4">
          {mockSessions.map(session => (
            <SessionCard
              key={session.id}
              session={session}
              level={user.level}
              onClick={() => setSelectedSession(session)}
            />
          ))}
        </div>
      </div>

      {/* Session Modal */}
      {selectedSession && (
        <SessionModal
          session={selectedSession}
          level={user.level}
          isOpen={!!selectedSession}
          onClose={() => setSelectedSession(null)}
          onDocumentRead={handleDocumentRead}
          onTaskSubmit={handleTaskSubmit}
        />
      )}
    </div>
  );
}
```

## 2. Using Button Component

```jsx
import { Button } from '../components';
import { Save, Upload, Trash } from 'lucide-react';

function Examples() {
  return (
    <div className="space-y-4">
      {/* Primary Button */}
      <Button variant="primary" size="lg" onClick={handleSave}>
        Save Changes
      </Button>

      {/* Button with Icon */}
      <Button variant="success" icon={Upload} iconPosition="left">
        Upload File
      </Button>

      {/* Loading Button */}
      <Button variant="primary" loading={isSubmitting}>
        Submitting...
      </Button>

      {/* Danger Button */}
      <Button variant="danger" icon={Trash} iconPosition="right">
        Delete
      </Button>

      {/* Full Width */}
      <Button variant="primary" fullWidth>
        Continue
      </Button>
    </div>
  );
}
```

## 3. Using Modal Component

```jsx
import { Modal, Button } from '../components';

function ConfirmationModal() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <Button onClick={() => setIsOpen(true)}>Open Modal</Button>

      <Modal
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        title="Confirm Action"
        size="md"
      >
        <p className="text-slate-300 mb-6">
          Are you sure you want to proceed? This action cannot be undone.
        </p>
        <div className="flex space-x-4">
          <Button variant="danger" onClick={handleConfirm} fullWidth>
            Confirm
          </Button>
          <Button variant="secondary" onClick={() => setIsOpen(false)} fullWidth>
            Cancel
          </Button>
        </div>
      </Modal>
    </>
  );
}
```

## 4. Using Notifications

```jsx
import { useNotification } from '../hooks';

function FormExample() {
  const notify = useNotification();

  const handleSubmit = async (data) => {
    try {
      await api.submit(data);
      notify.success('Form submitted successfully!');
    } catch (error) {
      notify.error('Submission failed. Please try again.');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      {/* form fields */}
      <Button type="submit">Submit</Button>
    </form>
  );
}

// In App.jsx, add NotificationContainer
import { NotificationContainer } from './components';
import { useApp } from './contexts/AppContext';

function App() {
  const { notifications } = useApp();
  
  return (
    <>
      <NotificationContainer notifications={notifications} />
      {/* rest of app */}
    </>
  );
}
```

## 5. Using Timer Hook

```jsx
import { useTimer, useCountdown } from '../hooks';

function TimerExample() {
  // Countdown timer (e.g., for tasks)
  const timer = useTimer(3600); // 1 hour in seconds

  return (
    <div>
      <div className="text-2xl font-bold">{timer.formatted}</div>
      <div className="space-x-2">
        <button onClick={timer.start}>Start</button>
        <button onClick={timer.pause}>Pause</button>
        <button onClick={timer.reset}>Reset</button>
      </div>
    </div>
  );
}

function DeadlineExample({ deadline }) {
  // Countdown to specific date
  const countdown = useCountdown(deadline);

  return (
    <div className={countdown.isExpired ? 'text-rose-400' : 'text-emerald-400'}>
      {countdown.isExpired ? 'Expired' : countdown.formatted}
    </div>
  );
}
```

## 6. Using Session Hook

```jsx
import { useSession } from '../hooks';

function SessionWorkflow({ sessionId }) {
  const { markDocumentAsRead, submitTask, loading, error } = useSession();

  const handleReadDocument = async () => {
    const result = await markDocumentAsRead(sessionId);
    if (result.success) {
      console.log('Document read!');
    }
  };

  const handleSubmitTask = async (file) => {
    const result = await submitTask(sessionId, file);
    if (result.success) {
      console.log('Task submitted!');
    }
  };

  return (
    <div>
      <Button onClick={handleReadDocument} loading={loading}>
        Mark as Read
      </Button>
      {error && <p className="text-rose-400">{error}</p>}
    </div>
  );
}
```

## 7. Path Aliases in Action

```jsx
// Instead of messy relative imports:
import { Button } from '../../../components/common/Button';
import { LEVEL_CONFIG } from '../../../constants/levelConfig';
import { formatDate } from '../../../utils/helpers';

// Use clean path aliases:
import { Button } from '@components';
import { LEVEL_CONFIG } from '@constants/levelConfig';
import { formatDate } from '@utils/helpers';
```

## 8. Complete Feature Example

```jsx
// src/pages/EnhancedStudentDashboard.jsx
import React, { useState, useEffect } from 'react';
import { useAuth } from '@contexts/AuthContext';
import {
  StatCard, ProgressBar, LevelInfo,
  SessionCard, SessionModal, Loader
} from '@components';
import { useSession, useNotification, useCountdown } from '@hooks';
import { get } from '@utils/api';
import { API_ENDPOINTS } from '@constants/apiConfig';

export default function EnhancedStudentDashboard() {
  const { user } = useAuth();
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedSession, setSelectedSession] = useState(null);
  
  const sessionHook = useSession();
  const notify = useNotification();

  useEffect(() => {
    loadSessions();
  }, []);

  const loadSessions = async () => {
    setLoading(true);
    const result = await get(API_ENDPOINTS.STUDENT_SESSIONS);
    if (result.success) {
      setSessions(result.data);
    } else {
      notify.error('Failed to load sessions');
    }
    setLoading(false);
  };

  const handleDocumentRead = async (sessionId) => {
    const result = await sessionHook.markDocumentAsRead(sessionId);
    if (result.success) {
      notify.success('Document marked as read!');
      loadSessions(); // Reload to get updated data
    } else {
      notify.error(result.error);
    }
  };

  const handleTaskSubmit = async (sessionId, file) => {
    const result = await sessionHook.submitTask(sessionId, file);
    if (result.success) {
      notify.success('Task submitted successfully!');
      setSelectedSession(null);
      loadSessions();
    } else {
      notify.error(result.error);
    }
  };

  if (loading) return <Loader size="lg" text="Loading your dashboard..." />;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900">
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats, Progress, Level Info */}
        {/* ... */}

        {/* Sessions */}
        <div className="mt-8 space-y-4">
          {sessions.map(session => (
            <SessionCard
              key={session.id}
              session={session}
              level={user.level}
              onClick={() => setSelectedSession(session)}
            />
          ))}
        </div>
      </div>

      {selectedSession && (
        <SessionModal
          session={selectedSession}
          level={user.level}
          isOpen={true}
          onClose={() => setSelectedSession(null)}
          onDocumentRead={handleDocumentRead}
          onTaskSubmit={handleTaskSubmit}
        />
      )}
    </div>
  );
}
```

## 9. Form with Input Component

```jsx
import { Input, Button } from '@components';
import { Mail, Lock, User } from 'lucide-react';

function RegistrationForm() {
  const [formData, setFormData] = useState({
    name: '', email: '', password: ''
  });
  const [errors, setErrors] = useState({});

  return (
    <form className="space-y-4">
      <Input
        label="Full Name"
        icon={User}
        value={formData.name}
        onChange={(e) => setFormData({...formData, name: e.target.value})}
        error={errors.name}
        placeholder="John Doe"
      />
      
      <Input
        label="Email Address"
        icon={Mail}
        type="email"
        value={formData.email}
        onChange={(e) => setFormData({...formData, email: e.target.value})}
        error={errors.email}
        placeholder="john@example.com"
      />
      
      <Input
        label="Password"
        icon={Lock}
        type="password"
        value={formData.password}
        onChange={(e) => setFormData({...formData, password: e.target.value})}
        error={errors.password}
        placeholder="••••••••"
      />
      
      <Button type="submit" variant="primary" fullWidth>
        Create Account
      </Button>
    </form>
  );
}
```

## 10. Supervisor Dashboard Example

```jsx
import { StudentTable, StudentDetailModal } from '@components';

function SupervisorDashboard() {
  const [students, setStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);

  const handleApprove = (studentId) => {
    // Approve certificate logic
    console.log('Approving certificate for:', studentId);
  };

  const handleExtend = (studentId) => {
    // Extend deadline logic
    console.log('Extending deadline for:', studentId);
  };

  return (
    <>
      <StudentTable
        students={students}
        onSelectStudent={setSelectedStudent}
      />

      <StudentDetailModal
        student={selectedStudent}
        isOpen={!!selectedStudent}
        onClose={() => setSelectedStudent(null)}
        onApprove={handleApprove}
        onExtend={handleExtend}
      />
    </>
  );
}
```

---

## 💡 Pro Tips

1. **Always use path aliases** for cleaner imports
2. **Combine hooks** for powerful functionality
3. **Use NotificationContainer** at app level
4. **Wrap async calls** with try-catch
5. **Check loading states** before rendering
6. **Use TypeScript types** if converting to TS
7. **Follow naming conventions** from existing code
8. **Test components** in isolation first

## 🎯 Next Steps

1. Copy these examples to your pages
2. Replace mock data with API calls
3. Add error boundaries
4. Implement loading states
5. Test on different screen sizes
6. Add animations and transitions
7. Optimize performance
8. Write unit tests

Happy coding! 🚀
