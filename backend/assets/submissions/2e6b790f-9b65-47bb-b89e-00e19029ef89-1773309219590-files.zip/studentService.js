/**
 * Student Service
 * Handles all student-related API calls
 */

import { get, post, put, uploadFile } from '../utils/api';
import { API_ENDPOINTS } from '../constants/apiConfig';

export const studentService = {
  /**
   * Get student profile
   */
  async getProfile() {
    return await get(API_ENDPOINTS.STUDENT_PROFILE);
  },

  /**
   * Get all sessions for student
   */
  async getSessions() {
    return await get(API_ENDPOINTS.STUDENT_SESSIONS);
  },

  /**
   * Get student progress
   */
  async getProgress() {
    return await get(API_ENDPOINTS.STUDENT_PROGRESS);
  },

  /**
   * Update student profile
   */
  async updateProfile(data) {
    return await put(API_ENDPOINTS.UPDATE_PROFILE, data);
  },

  /**
   * Mark document as read
   */
  async markDocumentRead(sessionId) {
    return await post(
      API_ENDPOINTS.READ_DOCUMENT.replace(':id', sessionId)
    );
  },

  /**
   * Submit task
   */
  async submitTask(sessionId, file, onProgress) {
    return await uploadFile(
      API_ENDPOINTS.SUBMIT_TASK.replace(':id', sessionId),
      file,
      onProgress
    );
  },

  /**
   * Get session details
   */
  async getSession(sessionId) {
    return await get(
      API_ENDPOINTS.GET_SESSION.replace(':id', sessionId)
    );
  },

  /**
   * Get submission details
   */
  async getSubmission(sessionId) {
    return await get(
      API_ENDPOINTS.GET_SUBMISSION.replace(':id', sessionId)
    );
  }
};
