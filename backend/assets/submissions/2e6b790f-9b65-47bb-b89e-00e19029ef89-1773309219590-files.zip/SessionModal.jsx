import React, { useState } from 'react';
import Modal from '../common/Modal';
import DocumentReader from './DocumentReader';
import TaskSubmission from './TaskSubmission';
import { Clock } from 'lucide-react';
import { LEVEL_CONFIG } from '../../constants/levelConfig';

export default function SessionModal({ session, level, isOpen, onClose, onDocumentRead, onTaskSubmit }) {
  const [currentStep, setCurrentStep] = useState(
    session.documentRead ? (session.taskUnlocked ? 'task' : 'document') : 'document'
  );
  const config = LEVEL_CONFIG[level];

  const handleDocumentRead = () => {
    onDocumentRead(session.id);
    setCurrentStep('task');
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="lg" showCloseButton={true}>
      {/* Header */}
      <div className="mb-6">
        <h3 className="text-2xl font-bold text-white mb-2">{session.title}</h3>
        <div className="flex items-center space-x-4 text-sm text-slate-400">
          <div className="flex items-center space-x-2">
            <Clock className="w-4 h-4" />
            <span>{session.timeRemaining}h remaining</span>
          </div>
          <div className={`px-2 py-1 rounded text-xs font-semibold ${config.colorClasses.bgLight} ${config.colorClasses.text}`}>
            {config.deadline} hour deadline
          </div>
        </div>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center space-x-4 mb-8">
        <Step number={1} label="Read Document" active={currentStep === 'document'} 
          completed={session.documentRead} color={config.color} />
        <div className="flex-1 h-0.5 bg-slate-800"></div>
        <Step number={2} label="Complete Task" active={currentStep === 'task'}
          completed={session.submitted} color={config.color} disabled={!session.documentRead} />
      </div>

      {/* Content */}
      {currentStep === 'document' && (
        <DocumentReader session={session} config={config} onRead={handleDocumentRead} />
      )}
      {currentStep === 'task' && (
        <TaskSubmission session={session} config={config} onSubmit={onTaskSubmit} />
      )}
    </Modal>
  );
}

function Step({ number, label, active, completed, color, disabled }) {
  const colors = {
    emerald: { active: 'bg-emerald-500/20 text-emerald-400 ring-2 ring-emerald-500', completed: 'bg-emerald-500 text-white' },
    amber: { active: 'bg-amber-500/20 text-amber-400 ring-2 ring-amber-500', completed: 'bg-amber-500 text-white' },
    rose: { active: 'bg-rose-500/20 text-rose-400 ring-2 ring-rose-500', completed: 'bg-rose-500 text-white' },
  };

  return (
    <div className="flex items-center space-x-3">
      <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold transition-all ${
        completed ? colors[color].completed :
        active && !disabled ? colors[color].active :
        'bg-slate-800 text-slate-500'
      }`}>
        {completed ? '✓' : number}
      </div>
      <span className={`font-medium ${active || completed ? 'text-white' : 'text-slate-500'}`}>
        {label}
      </span>
    </div>
  );
}
