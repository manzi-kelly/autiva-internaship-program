import React from 'react';
import { Clock, FileText } from 'lucide-react';
import { LEVEL_CONFIG } from '../../constants/levelConfig';

export default function LevelInfo({ level }) {
  const config = LEVEL_CONFIG[level];
  if (!config) return null;

  return (
    <div className="bg-slate-900/50 backdrop-blur-xl rounded-2xl p-6 border border-slate-800">
      <h2 className="text-xl font-bold text-white mb-4">{config.name}</h2>
      <p className="text-slate-400 mb-4">{config.description}</p>
      
      <div className="flex flex-wrap gap-2 mb-4">
        {config.focus.map((tech, i) => (
          <span
            key={i}
            className={`px-3 py-1 rounded-lg text-sm font-medium ${config.colorClasses.bgLight} ${config.colorClasses.text}`}
          >
            {tech}
          </span>
        ))}
      </div>

      <div className="flex items-center space-x-6 text-sm text-slate-400">
        <div className="flex items-center space-x-2">
          <Clock className="w-4 h-4" />
          <span>{config.deadline} hours per session</span>
        </div>
        <div className="flex items-center space-x-2">
          <FileText className="w-4 h-4" />
          <span>{config.sessions} total sessions</span>
        </div>
      </div>
    </div>
  );
}
