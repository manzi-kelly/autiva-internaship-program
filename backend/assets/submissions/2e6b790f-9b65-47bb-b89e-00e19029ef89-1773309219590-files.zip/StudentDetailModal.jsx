import React from 'react';
import Modal from '../common/Modal';
import Button from '../common/Button';
import { LEVEL_CONFIG } from '../../constants/levelConfig';

export default function StudentDetailModal({ student, isOpen, onClose, onApprove, onExtend }) {
  if (!student) return null;
  
  const config = LEVEL_CONFIG[student.level];

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="lg" title={`${student.firstName} ${student.lastName}`}>
      <div className="space-y-6">
        <div className="grid md:grid-cols-2 gap-6">
          <InfoCard label="Email" value={student.email} />
          <InfoCard label="School" value={student.school} />
          <InfoCard label="Level" value={student.level} />
          <InfoCard label="Started" value={new Date(student.internshipStartDate).toLocaleDateString()} />
        </div>
        
        <div className="space-y-3">
          <h4 className="font-semibold text-white">Session Progress</h4>
          {student.sessions && student.sessions.slice(0, 5).map((session) => (
            <div key={session.id} className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
              <div className="flex items-center justify-between">
                <span className="text-white">{session.title}</span>
                <span className={`px-2 py-1 rounded text-sm ${
                  session.submitted ? `${config.colorClasses.bgLight} ${config.colorClasses.text}`
                    : session.taskUnlocked ? 'bg-blue-500/20 text-blue-400'
                    : 'bg-slate-700 text-slate-400'
                }`}>
                  {session.submitted ? `Completed (${session.score})` : session.taskUnlocked ? 'In Progress' : 'Locked'}
                </span>
              </div>
            </div>
          ))}
        </div>

        <div className="flex space-x-4">
          <Button variant="success" fullWidth onClick={() => onApprove(student.id)}>
            Approve Certificate
          </Button>
          <Button variant="secondary" fullWidth onClick={() => onExtend(student.id)}>
            Extend Deadline
          </Button>
        </div>
      </div>
    </Modal>
  );
}

function InfoCard({ label, value }) {
  return (
    <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
      <div className="text-sm text-slate-400 mb-1">{label}</div>
      <div className="font-medium text-white">{value}</div>
    </div>
  );
}
