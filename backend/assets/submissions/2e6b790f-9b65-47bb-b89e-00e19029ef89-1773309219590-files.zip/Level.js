/**
 * Level Model
 * Handles all database operations related to internship levels
 */

const db = require('../config/database');

class LevelModel {
  /**
   * Get all available levels
   * @returns {Promise<Array>} List of levels
   */
  static async getAll() {
    const query = `
      SELECT level_id, level_name, description, total_sessions, 
             session_duration_hours, required_pass_sessions, price
      FROM levels
      ORDER BY level_id
    `;
    
    const result = await db.query(query);
    return result.rows;
  }

  /**
   * Get level by ID
   * @param {string} levelId - Level ID (L3, L4, L5)
   * @returns {Promise<Object>} Level data
   */
  static async getById(levelId) {
    const query = `
      SELECT level_id, level_name, description, total_sessions, 
             session_duration_hours, required_pass_sessions, price
      FROM levels
      WHERE level_id = $1
    `;
    
    const result = await db.query(query, [levelId]);
    return result.rows[0];
  }

  /**
   * Get level with sessions and tasks
   * @param {string} levelId - Level ID
   * @returns {Promise<Object>} Level with sessions and tasks
   */
  static async getWithSessions(levelId) {
    // Get level info
    const levelQuery = `
      SELECT level_id, level_name, description, total_sessions, 
             session_duration_hours, required_pass_sessions, price
      FROM levels
      WHERE level_id = $1
    `;
    
    const levelResult = await db.query(levelQuery, [levelId]);
    
    if (levelResult.rows.length === 0) {
      return null;
    }
    
    const level = levelResult.rows[0];
    
    // Get sessions with tasks
    const sessionsQuery = `
      SELECT 
        s.session_id,
        s.session_number,
        s.session_title,
        s.description,
        s.duration_hours,
        json_agg(
          json_build_object(
            'task_id', t.task_id,
            'task_title', t.task_title,
            'task_description', t.task_description,
            'max_score', t.max_score
          )
        ) as tasks
      FROM sessions s
      LEFT JOIN tasks t ON s.session_id = t.session_id
      WHERE s.level_id = $1
      GROUP BY s.session_id, s.session_number, s.session_title, s.description, s.duration_hours
      ORDER BY s.session_number
    `;
    
    const sessionsResult = await db.query(sessionsQuery, [levelId]);
    
    level.sessions = sessionsResult.rows;
    
    return level;
  }

  /**
   * Get student progress for a level
   * @param {number} userId - User ID
   * @param {string} levelId - Level ID
   * @returns {Promise<Object>} Progress data
   */
  static async getStudentProgress(userId, levelId) {
    const query = `
      SELECT 
        sp.*,
        l.level_name,
        l.total_sessions,
        l.required_pass_sessions
      FROM student_progress sp
      JOIN levels l ON sp.level_id = l.level_id
      WHERE sp.user_id = $1 AND sp.level_id = $2
    `;
    
    const result = await db.query(query, [userId, levelId]);
    return result.rows[0];
  }
}

module.exports = LevelModel;
