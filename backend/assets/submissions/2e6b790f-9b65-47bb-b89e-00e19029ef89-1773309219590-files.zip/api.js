import axios from 'axios';
import { API_BASE_URL, REQUEST_TIMEOUT } from '../constants/apiConfig.js';

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: REQUEST_TIMEOUT,
  headers: { 'Content-Type': 'application/json' }
});

apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('authToken');
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => Promise.reject(error)
);

export const apiRequest = async (method, url, data = null, config = {}) => {
  try {
    const response = await apiClient({ method, url, data, ...config });
    return { success: true, data: response.data };
  } catch (error) {
    return { success: false, error: error.response?.data?.message || error.message };
  }
};

export const get = (url, config = {}) => apiRequest('GET', url, null, config);
export const post = (url, data, config = {}) => apiRequest('POST', url, data, config);
export const put = (url, data, config = {}) => apiRequest('PUT', url, data, config);
export const del = (url, config = {}) => apiRequest('DELETE', url, null, config);

export const uploadFile = async (url, file) => {
  const formData = new FormData();
  formData.append('file', file);
  return apiRequest('POST', url, formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  });
};

export default apiClient;
