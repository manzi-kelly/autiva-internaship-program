/**
 * User Model
 * Handles all database operations related to users
 */

const db = require('../config/database');
const bcrypt = require('bcryptjs');

class UserModel {
  /**
   * Create a new user
   * @param {Object} userData - User data
   * @returns {Promise<Object>} Created user
   */
  static async create(userData) {
    const { firstName, lastName, email, password, role = 'student', school } = userData;
    
    // Hash password
    const passwordHash = await bcrypt.hash(password, 10);
    
    const query = `
      INSERT INTO users (first_name, last_name, email, password_hash, role, school_institution)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING user_id, first_name, last_name, email, role, school_institution, created_at
    `;
    
    const result = await db.query(query, [firstName, lastName, email, passwordHash, role, school]);
    return result.rows[0];
  }

  /**
   * Find user by email
   * @param {string} email - User email
   * @returns {Promise<Object>} User data
   */
  static async findByEmail(email) {
    const query = `
      SELECT user_id, first_name, last_name, email, password_hash, role, 
             school_institution, is_active, created_at
      FROM users
      WHERE email = $1
    `;
    
    const result = await db.query(query, [email]);
    return result.rows[0];
  }

  /**
   * Find user by ID
   * @param {number} userId - User ID
   * @returns {Promise<Object>} User data
   */
  static async findById(userId) {
    const query = `
      SELECT user_id, first_name, last_name, email, role, 
             school_institution, phone, profile_picture, is_active, created_at
      FROM users
      WHERE user_id = $1
    `;
    
    const result = await db.query(query, [userId]);
    return result.rows[0];
  }

  /**
   * Verify user password
   * @param {string} password - Plain text password
   * @param {string} hash - Hashed password
   * @returns {Promise<boolean>} Password match result
   */
  static async verifyPassword(password, hash) {
    return await bcrypt.compare(password, hash);
  }

  /**
   * Update user profile
   * @param {number} userId - User ID
   * @param {Object} updateData - Data to update
   * @returns {Promise<Object>} Updated user
   */
  static async update(userId, updateData) {
    const { firstName, lastName, school, phone } = updateData;
    
    const query = `
      UPDATE users
      SET first_name = COALESCE($1, first_name),
          last_name = COALESCE($2, last_name),
          school_institution = COALESCE($3, school_institution),
          phone = COALESCE($4, phone)
      WHERE user_id = $5
      RETURNING user_id, first_name, last_name, email, role, school_institution, phone
    `;
    
    const result = await db.query(query, [firstName, lastName, school, phone, userId]);
    return result.rows[0];
  }

  /**
   * Get all students with their progress
   * @returns {Promise<Array>} List of students
   */
  static async getAllStudents() {
    const query = `
      SELECT 
        u.user_id,
        u.first_name,
        u.last_name,
        u.email,
        u.school_institution,
        sp.level_id,
        l.level_name,
        sp.internship_start_date,
        sp.completed_sessions,
        sp.total_score,
        sp.is_eligible_for_certificate,
        sp.status as progress_status
      FROM users u
      LEFT JOIN student_progress sp ON u.user_id = sp.user_id
      LEFT JOIN levels l ON sp.level_id = l.level_id
      WHERE u.role = 'student'
      ORDER BY u.created_at DESC
    `;
    
    const result = await db.query(query);
    return result.rows;
  }

  /**
   * Check if email exists
   * @param {string} email - Email to check
   * @returns {Promise<boolean>} Email exists or not
   */
  static async emailExists(email) {
    const query = 'SELECT user_id FROM users WHERE email = $1';
    const result = await db.query(query, [email]);
    return result.rows.length > 0;
  }
}

module.exports = UserModel;
