import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function NotFoundPage() {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900">
      <div className="text-center">
        <h1 className="text-6xl font-bold text-white mb-4">404</h1>
        <p className="text-slate-400 mb-8">Page not found</p>
        <button onClick={() => navigate('/')} className="px-6 py-3 bg-emerald-500 text-white rounded-xl">
          Go Home
        </button>
      </div>
    </div>
  );
}
