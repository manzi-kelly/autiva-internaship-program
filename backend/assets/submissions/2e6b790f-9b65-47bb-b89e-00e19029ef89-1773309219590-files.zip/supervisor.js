/**
 * Supervisor Routes
 * Routes for supervisor/admin operations
 */

const express = require('express');
const router = express.Router();
const SupervisorController = require('../controllers/supervisorController');
const { authenticate, authorize } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

// All routes require authentication and supervisor/admin role
router.use(authenticate);
router.use(authorize('supervisor', 'admin'));

// Dashboard
router.get('/dashboard', asyncHandler(SupervisorController.getDashboard));

// Student management
router.get('/students', asyncHandler(SupervisorController.getAllStudents));
router.get('/students/:userId', asyncHandler(SupervisorController.getStudentDetails));

// Payment verification
router.get('/payments/pending', asyncHandler(SupervisorController.getPendingPayments));
router.post('/payments/:paymentId/verify', asyncHandler(SupervisorController.verifyPayment));

// Submission grading
router.get('/submissions/:submissionId', asyncHandler(SupervisorController.getSubmissionDetails));
router.post('/submissions/:submissionId/grade', asyncHandler(SupervisorController.gradeSubmission));

// Recovery requests
router.get('/recoveries/pending', asyncHandler(SupervisorController.getPendingRecoveries));
router.post('/recoveries/:submissionId/approve', asyncHandler(SupervisorController.approveRecovery));

module.exports = router;
