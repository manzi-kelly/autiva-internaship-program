import React from 'react';

export default function Input({
  label, error, icon: Icon, type = 'text', className = '', ...props
}) {
  return (
    <div className="space-y-2">
      {label && <label className="block text-sm font-medium text-slate-300">{label}</label>}
      <div className="relative">
        {Icon && <Icon className="absolute left-3 top-3 w-5 h-5 text-slate-500" />}
        <input
          type={type}
          className={`w-full ${Icon ? 'pl-10' : 'pl-4'} pr-4 py-3 bg-slate-800/50 border ${
            error ? 'border-rose-500' : 'border-slate-700'
          } rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all ${className}`}
          {...props}
        />
      </div>
      {error && <p className="text-sm text-rose-400">{error}</p>}
    </div>
  );
}
