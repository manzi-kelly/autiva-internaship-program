import React, { useState, useEffect } from 'react';
import { Clock, BookOpen, CheckCircle, Upload, Award, Users, Calendar, TrendingUp, Lock, Unlock, AlertCircle, FileText, Timer } from 'lucide-react';

// Main App Component
export default function InternshipManagementSystem() {
  const [currentUser, setCurrentUser] = useState(null);
  const [currentView, setCurrentView] = useState('login');
  const [students, setStudents] = useState([
    {
      id: 1,
      firstName: 'Alice',
      lastName: 'Johnson',
      email: 'alice@example.com',
      level: 'L3',
      school: 'Tech University',
      internshipStartDate: new Date('2024-02-15'),
      sessions: Array.from({ length: 10 }, (_, i) => ({
        id: i + 1,
        title: `Session ${i + 1}: ${['HTML Basics', 'CSS Fundamentals', 'Layout Design', 'Responsive Web', 'Forms & Inputs', 'CSS Grid', 'Flexbox Advanced', 'Animations', 'Web Accessibility', 'Final Project'][i]}`,
        documentRead: i < 3,
        taskUnlocked: i < 3,
        submitted: i < 2,
        score: i < 2 ? 85 + i * 5 : 0,
        deadline: 8,
        timeRemaining: i === 2 ? 4.5 : i > 2 ? 8 : 0
      })),
      completedSessions: 2,
      paymentConfirmed: true
    }
  ]);

  // Level configuration
  const levelConfig = {
    L3: {
      name: 'Level 3 - Frontend Fundamentals',
      color: 'emerald',
      sessions: 10,
      deadline: 8,
      focus: ['HTML', 'CSS', 'Web Layout Design'],
      passingRequirement: 8
    },
    L4: {
      name: 'Level 4 - Backend Development',
      color: 'amber',
      sessions: 5,
      deadline: 10,
      focus: ['MySQL', 'PHP', 'Node.js'],
      passingRequirement: 4
    },
    L5: {
      name: 'Level 5 - Full-Stack Architecture',
      color: 'rose',
      sessions: 3,
      deadline: 48,
      focus: ['React.js', 'CRUD Operations', 'Database Integration'],
      passingRequirement: 3
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900">
      {!currentUser ? (
        <AuthPage 
          onLogin={setCurrentUser}
          currentView={currentView}
          setCurrentView={setCurrentView}
        />
      ) : currentUser.role === 'student' ? (
        <StudentDashboard 
          user={currentUser}
          levelConfig={levelConfig}
          onLogout={() => setCurrentUser(null)}
        />
      ) : (
        <SupervisorDashboard 
          students={students}
          setStudents={setStudents}
          onLogout={() => setCurrentUser(null)}
        />
      )}
    </div>
  );
}

// Authentication Page Component
function AuthPage({ onLogin, currentView, setCurrentView }) {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    school: '',
    level: 'L3'
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (currentView === 'login') {
      // Demo login
      onLogin({
        role: formData.email.includes('supervisor') ? 'supervisor' : 'student',
        ...formData,
        id: 1,
        internshipStartDate: new Date(),
        completedSessions: 2,
        sessions: Array.from({ length: 10 }, (_, i) => ({
          id: i + 1,
          title: `Session ${i + 1}`,
          documentRead: i < 3,
          taskUnlocked: i < 3,
          submitted: i < 2,
          score: i < 2 ? 85 + i * 5 : 0,
          deadline: 8,
          timeRemaining: i === 2 ? 4.5 : i > 2 ? 8 : 0
        }))
      });
    } else {
      setCurrentView('payment');
    }
  };

  if (currentView === 'payment') {
    return <PaymentPage onComplete={() => {
      onLogin({ role: 'student', ...formData, id: 1 });
    }} />;
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-6xl grid md:grid-cols-2 gap-8">
        {/* Left Side - Branding */}
        <div className="flex flex-col justify-center space-y-6 text-white">
          <div className="space-y-4">
            <div className="inline-block">
              <div className="text-6xl font-bold bg-gradient-to-r from-emerald-400 via-amber-400 to-rose-400 bg-clip-text text-transparent">
                InternHub
              </div>
            </div>
            <h2 className="text-3xl font-bold">Professional Internship Training</h2>
            <p className="text-slate-300 text-lg">
              Master web development through structured, hands-on internship programs designed for all skill levels.
            </p>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center flex-shrink-0">
                <BookOpen className="w-6 h-6 text-emerald-400" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Level-Based Learning</h3>
                <p className="text-slate-400">Structured curriculum from HTML/CSS to Full-Stack Development</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 rounded-xl bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                <Timer className="w-6 h-6 text-amber-400" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Time-Tracked Sessions</h3>
                <p className="text-slate-400">Complete practical tasks within deadlines to build discipline</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 rounded-xl bg-rose-500/20 flex items-center justify-center flex-shrink-0">
                <Award className="w-6 h-6 text-rose-400" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Certificate Recognition</h3>
                <p className="text-slate-400">Earn industry-recognized certificates upon completion</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side - Form */}
        <div className="bg-slate-900/50 backdrop-blur-xl rounded-3xl p-8 border border-slate-800">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-white mb-2">
              {currentView === 'login' ? 'Welcome Back' : 'Start Your Journey'}
            </h2>
            <p className="text-slate-400">
              {currentView === 'login' ? 'Sign in to continue your internship' : 'Register to begin your professional training'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {currentView === 'register' && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <input
                    type="text"
                    placeholder="First Name"
                    className="px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all"
                    value={formData.firstName}
                    onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                    required
                  />
                  <input
                    type="text"
                    placeholder="Last Name"
                    className="px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all"
                    value={formData.lastName}
                    onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                    required
                  />
                </div>
                <input
                  type="text"
                  placeholder="School / Institution"
                  className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all"
                  value={formData.school}
                  onChange={(e) => setFormData({...formData, school: e.target.value})}
                  required
                />
              </>
            )}

            <input
              type="email"
              placeholder="Email Address"
              className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all"
              value={formData.email}
              onChange={(e) => setFormData({...formData, email: e.target.value})}
              required
            />

            <input
              type="password"
              placeholder="Password"
              className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all"
              value={formData.password}
              onChange={(e) => setFormData({...formData, password: e.target.value})}
              required
            />

            {currentView === 'register' && (
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Select Your Level</label>
                <div className="grid grid-cols-3 gap-3">
                  {['L3', 'L4', 'L5'].map(level => (
                    <button
                      key={level}
                      type="button"
                      onClick={() => setFormData({...formData, level})}
                      className={`px-4 py-3 rounded-xl font-semibold transition-all ${
                        formData.level === level
                          ? level === 'L3' ? 'bg-emerald-500 text-white'
                            : level === 'L4' ? 'bg-amber-500 text-white'
                            : 'bg-rose-500 text-white'
                          : 'bg-slate-800/50 text-slate-400 border border-slate-700 hover:border-slate-600'
                      }`}
                    >
                      {level}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-4 bg-gradient-to-r from-emerald-500 via-amber-500 to-rose-500 rounded-xl font-semibold text-white hover:shadow-lg hover:shadow-emerald-500/25 transition-all duration-300 transform hover:scale-[1.02]"
            >
              {currentView === 'login' ? 'Sign In' : 'Continue to Payment'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <button
              onClick={() => setCurrentView(currentView === 'login' ? 'register' : 'login')}
              className="text-slate-400 hover:text-emerald-400 transition-colors"
            >
              {currentView === 'login' ? "Don't have an account? Register" : "Already have an account? Sign In"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// Payment Page Component
function PaymentPage({ onComplete }) {
  const [paymentMethod, setPaymentMethod] = useState('card');

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-slate-900/50 backdrop-blur-xl rounded-3xl p-8 border border-slate-800">
        <div className="text-center mb-8">
          <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-emerald-500 to-amber-500 flex items-center justify-center">
            <Award className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-3xl font-bold text-white mb-2">Complete Your Registration</h2>
          <p className="text-slate-400">Secure payment to activate your internship account</p>
        </div>

        <div className="space-y-6">
          <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
            <div className="flex justify-between items-center mb-4">
              <span className="text-slate-300">Internship Registration Fee</span>
              <span className="text-2xl font-bold text-white">$299</span>
            </div>
            <div className="text-sm text-slate-400 space-y-1">
              <div className="flex justify-between">
                <span>• Full curriculum access</span>
              </div>
              <div className="flex justify-between">
                <span>• Certificate upon completion</span>
              </div>
              <div className="flex justify-between">
                <span>• Supervisor support</span>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-3">Payment Method</label>
            <div className="grid grid-cols-2 gap-3">
              {['card', 'paypal'].map(method => (
                <button
                  key={method}
                  onClick={() => setPaymentMethod(method)}
                  className={`px-4 py-3 rounded-xl font-medium transition-all ${
                    paymentMethod === method
                      ? 'bg-emerald-500 text-white'
                      : 'bg-slate-800/50 text-slate-400 border border-slate-700'
                  }`}
                >
                  {method === 'card' ? 'Credit Card' : 'PayPal'}
                </button>
              ))}
            </div>
          </div>

          {paymentMethod === 'card' && (
            <div className="space-y-4">
              <input
                type="text"
                placeholder="Card Number"
                className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="MM/YY"
                  className="px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
                <input
                  type="text"
                  placeholder="CVV"
                  className="px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          )}

          <button
            onClick={onComplete}
            className="w-full py-4 bg-gradient-to-r from-emerald-500 to-amber-500 rounded-xl font-semibold text-white hover:shadow-lg hover:shadow-emerald-500/25 transition-all"
          >
            Complete Payment & Start Internship
          </button>
        </div>
      </div>
    </div>
  );
}

// Student Dashboard Component
function StudentDashboard({ user, levelConfig, onLogout }) {
  const [selectedSession, setSelectedSession] = useState(null);
  const config = levelConfig[user.level];
  const progress = (user.completedSessions / config.sessions) * 100;
  const daysActive = Math.floor((new Date() - new Date(user.internshipStartDate)) / (1000 * 60 * 60 * 24));

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-slate-900/50 backdrop-blur-xl border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="text-2xl font-bold bg-gradient-to-r from-emerald-400 via-amber-400 to-rose-400 bg-clip-text text-transparent">
              InternHub
            </div>
            <div className={`px-3 py-1 rounded-lg text-sm font-semibold ${
              config.color === 'emerald' ? 'bg-emerald-500/20 text-emerald-400'
                : config.color === 'amber' ? 'bg-amber-500/20 text-amber-400'
                : 'bg-rose-500/20 text-rose-400'
            }`}>
              {user.level}
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <div className="text-sm text-slate-400">Welcome back,</div>
              <div className="font-semibold text-white">{user.firstName} {user.lastName}</div>
            </div>
            <button
              onClick={onLogout}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors"
            >
              Logout
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <StatCard
            icon={<Calendar className="w-6 h-6" />}
            label="Days Active"
            value={daysActive}
            color={config.color}
          />
          <StatCard
            icon={<CheckCircle className="w-6 h-6" />}
            label="Sessions Completed"
            value={`${user.completedSessions}/${config.sessions}`}
            color={config.color}
          />
          <StatCard
            icon={<TrendingUp className="w-6 h-6" />}
            label="Progress"
            value={`${Math.round(progress)}%`}
            color={config.color}
          />
          <StatCard
            icon={<Award className="w-6 h-6" />}
            label="Certificate"
            value={user.completedSessions >= config.passingRequirement ? 'Eligible' : 'Pending'}
            color={config.color}
          />
        </div>

        {/* Progress Bar */}
        <div className="bg-slate-900/50 backdrop-blur-xl rounded-2xl p-6 border border-slate-800 mb-8">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-white">Overall Progress</h3>
            <span className="text-sm text-slate-400">
              {config.passingRequirement} sessions required for certificate
            </span>
          </div>
          <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden">
            <div
              className={`h-full bg-gradient-to-r ${
                config.color === 'emerald' ? 'from-emerald-500 to-emerald-600'
                  : config.color === 'amber' ? 'from-amber-500 to-amber-600'
                  : 'from-rose-500 to-rose-600'
              } transition-all duration-1000`}
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Level Info */}
        <div className="bg-slate-900/50 backdrop-blur-xl rounded-2xl p-6 border border-slate-800 mb-8">
          <h2 className="text-xl font-bold text-white mb-4">{config.name}</h2>
          <div className="flex flex-wrap gap-2 mb-4">
            {config.focus.map((tech, i) => (
              <span
                key={i}
                className={`px-3 py-1 rounded-lg text-sm font-medium ${
                  config.color === 'emerald' ? 'bg-emerald-500/20 text-emerald-400'
                    : config.color === 'amber' ? 'bg-amber-500/20 text-amber-400'
                    : 'bg-rose-500/20 text-rose-400'
                }`}
              >
                {tech}
              </span>
            ))}
          </div>
          <div className="flex items-center space-x-6 text-sm text-slate-400">
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4" />
              <span>{config.deadline} hours per session</span>
            </div>
            <div className="flex items-center space-x-2">
              <FileText className="w-4 h-4" />
              <span>{config.sessions} total sessions</span>
            </div>
          </div>
        </div>

        {/* Sessions Grid */}
        <div className="space-y-4">
          <h3 className="text-xl font-bold text-white">Your Sessions</h3>
          <div className="grid gap-4">
            {user.sessions.map((session) => (
              <SessionCard
                key={session.id}
                session={session}
                config={config}
                onClick={() => setSelectedSession(session)}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Session Modal */}
      {selectedSession && (
        <SessionModal
          session={selectedSession}
          config={config}
          onClose={() => setSelectedSession(null)}
        />
      )}
    </div>
  );
}

// Stat Card Component
function StatCard({ icon, label, value, color }) {
  return (
    <div className="bg-slate-900/50 backdrop-blur-xl rounded-2xl p-6 border border-slate-800">
      <div className={`w-12 h-12 rounded-xl mb-4 flex items-center justify-center ${
        color === 'emerald' ? 'bg-emerald-500/20 text-emerald-400'
          : color === 'amber' ? 'bg-amber-500/20 text-amber-400'
          : 'bg-rose-500/20 text-rose-400'
      }`}>
        {icon}
      </div>
      <div className="text-sm text-slate-400 mb-1">{label}</div>
      <div className="text-2xl font-bold text-white">{value}</div>
    </div>
  );
}

// Session Card Component
function SessionCard({ session, config, onClick }) {
  const isLocked = !session.documentRead;
  const isActive = session.documentRead && !session.submitted;
  const isCompleted = session.submitted;

  return (
    <div
      onClick={!isLocked ? onClick : undefined}
      className={`bg-slate-900/50 backdrop-blur-xl rounded-2xl p-6 border transition-all ${
        isLocked
          ? 'border-slate-800 opacity-60 cursor-not-allowed'
          : 'border-slate-700 hover:border-slate-600 cursor-pointer hover:shadow-lg'
      }`}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center space-x-3 mb-2">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
              isCompleted
                ? config.color === 'emerald' ? 'bg-emerald-500/20 text-emerald-400'
                  : config.color === 'amber' ? 'bg-amber-500/20 text-amber-400'
                  : 'bg-rose-500/20 text-rose-400'
                : isLocked
                ? 'bg-slate-800 text-slate-600'
                : 'bg-slate-800 text-slate-400'
            }`}>
              {isLocked ? <Lock className="w-5 h-5" /> : isCompleted ? <CheckCircle className="w-5 h-5" /> : <Unlock className="w-5 h-5" />}
            </div>
            <div>
              <h4 className="font-semibold text-white">{session.title}</h4>
              <div className="flex items-center space-x-2 text-sm text-slate-400 mt-1">
                {isCompleted && (
                  <span className={`font-medium ${
                    config.color === 'emerald' ? 'text-emerald-400'
                      : config.color === 'amber' ? 'text-amber-400'
                      : 'text-rose-400'
                  }`}>
                    Score: {session.score}/100
                  </span>
                )}
                {isActive && (
                  <>
                    <Clock className="w-4 h-4" />
                    <span>{session.timeRemaining}h remaining</span>
                  </>
                )}
                {isLocked && <span>Read document to unlock</span>}
              </div>
            </div>
          </div>
        </div>
        
        {isCompleted && (
          <div className={`px-3 py-1 rounded-lg text-xs font-semibold ${
            config.color === 'emerald' ? 'bg-emerald-500/20 text-emerald-400'
              : config.color === 'amber' ? 'bg-amber-500/20 text-amber-400'
              : 'bg-rose-500/20 text-rose-400'
          }`}>
            Completed
          </div>
        )}
        {isActive && (
          <div className="px-3 py-1 rounded-lg text-xs font-semibold bg-blue-500/20 text-blue-400">
            In Progress
          </div>
        )}
        {isLocked && (
          <div className="px-3 py-1 rounded-lg text-xs font-semibold bg-slate-700 text-slate-400">
            Locked
          </div>
        )}
      </div>
    </div>
  );
}

// Session Modal Component
function SessionModal({ session, config, onClose }) {
  const [currentStep, setCurrentStep] = useState(session.documentRead ? (session.taskUnlocked ? 'task' : 'document') : 'document');
  const [documentRead, setDocumentRead] = useState(session.documentRead);
  const [file, setFile] = useState(null);

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="w-full max-w-4xl bg-slate-900 rounded-3xl border border-slate-800 max-h-[90vh] overflow-y-auto">
        {/* Modal Header */}
        <div className="sticky top-0 bg-slate-900 border-b border-slate-800 px-8 py-6 flex items-center justify-between">
          <div>
            <h3 className="text-2xl font-bold text-white">{session.title}</h3>
            <div className="flex items-center space-x-4 mt-2 text-sm text-slate-400">
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4" />
                <span>{session.timeRemaining}h remaining</span>
              </div>
              <div className={`px-2 py-1 rounded text-xs font-semibold ${
                config.color === 'emerald' ? 'bg-emerald-500/20 text-emerald-400'
                  : config.color === 'amber' ? 'bg-amber-500/20 text-amber-400'
                  : 'bg-rose-500/20 text-rose-400'
              }`}>
                {config.deadline} hour deadline
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 transition-colors"
          >
            ×
          </button>
        </div>

        {/* Progress Steps */}
        <div className="px-8 py-6 border-b border-slate-800">
          <div className="flex items-center space-x-4">
            <Step
              number={1}
              label="Read Document"
              active={currentStep === 'document'}
              completed={documentRead}
              color={config.color}
            />
            <div className="flex-1 h-0.5 bg-slate-800"></div>
            <Step
              number={2}
              label="Complete Task"
              active={currentStep === 'task'}
              completed={session.submitted}
              color={config.color}
              disabled={!documentRead}
            />
          </div>
        </div>

        {/* Content */}
        <div className="p-8">
          {currentStep === 'document' && (
            <div className="space-y-6">
              <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
                <div className="flex items-start space-x-4 mb-4">
                  <BookOpen className={`w-6 h-6 ${
                    config.color === 'emerald' ? 'text-emerald-400'
                      : config.color === 'amber' ? 'text-amber-400'
                      : 'text-rose-400'
                  }`} />
                  <div>
                    <h4 className="font-semibold text-white mb-2">Study Material</h4>
                    <p className="text-slate-400">
                      Carefully read and understand the following material before attempting the practical task. 
                      This document contains essential concepts you'll need to successfully complete the assignment.
                    </p>
                  </div>
                </div>
                
                {/* Simulated Document Content */}
                <div className="bg-slate-900/50 rounded-xl p-6 border border-slate-700 mt-4 space-y-4 text-slate-300">
                  <h5 className="font-semibold text-white text-lg">Introduction to {session.title.split(': ')[1]}</h5>
                  <p>
                    This session will cover fundamental concepts and practical applications. You'll learn key techniques, 
                    best practices, and common patterns used in professional development.
                  </p>
                  <p>
                    By the end of this session, you should be able to implement real-world solutions and understand 
                    the underlying principles that make your code efficient and maintainable.
                  </p>
                  <div className="bg-slate-800/50 rounded-lg p-4 border-l-4 border-emerald-500">
                    <p className="text-sm font-medium text-emerald-400">💡 Pro Tip</p>
                    <p className="text-sm mt-1">Take notes as you read. You'll need this knowledge for the practical task ahead.</p>
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-3 bg-amber-500/10 border border-amber-500/30 rounded-xl p-4">
                <AlertCircle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-amber-200">
                  You must confirm that you've read and understood this material before the task becomes available.
                  Please review carefully as the task will require this knowledge.
                </div>
              </div>

              <button
                onClick={() => {
                  setDocumentRead(true);
                  setCurrentStep('task');
                }}
                disabled={documentRead}
                className={`w-full py-4 rounded-xl font-semibold transition-all ${
                  documentRead
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                    : config.color === 'emerald'
                    ? 'bg-emerald-500 text-white hover:bg-emerald-600'
                    : config.color === 'amber'
                    ? 'bg-amber-500 text-white hover:bg-amber-600'
                    : 'bg-rose-500 text-white hover:bg-rose-600'
                }`}
              >
                {documentRead ? 'Document Reviewed ✓' : 'I Have Read & Understood'}
              </button>
            </div>
          )}

          {currentStep === 'task' && (
            <div className="space-y-6">
              <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
                <div className="flex items-start space-x-4 mb-4">
                  <FileText className={`w-6 h-6 ${
                    config.color === 'emerald' ? 'text-emerald-400'
                      : config.color === 'amber' ? 'text-amber-400'
                      : 'text-rose-400'
                  }`} />
                  <div>
                    <h4 className="font-semibold text-white mb-2">Practical Task</h4>
                    <p className="text-slate-400">
                      Apply what you've learned by completing this hands-on assignment. Your submission will be 
                      evaluated based on functionality, code quality, and adherence to best practices.
                    </p>
                  </div>
                </div>

                <div className="bg-slate-900/50 rounded-xl p-6 border border-slate-700 mt-4 space-y-4">
                  <h5 className="font-semibold text-white">Assignment Requirements:</h5>
                  <ul className="space-y-2 text-slate-300">
                    <li className="flex items-start space-x-2">
                      <span className={
                        config.color === 'emerald' ? 'text-emerald-400'
                          : config.color === 'amber' ? 'text-amber-400'
                          : 'text-rose-400'
                      }>•</span>
                      <span>Create a functional implementation based on the concepts from the study material</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <span className={
                        config.color === 'emerald' ? 'text-emerald-400'
                          : config.color === 'amber' ? 'text-amber-400'
                          : 'text-rose-400'
                      }>•</span>
                      <span>Follow best practices and maintain clean, readable code</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <span className={
                        config.color === 'emerald' ? 'text-emerald-400'
                          : config.color === 'amber' ? 'text-amber-400'
                          : 'text-rose-400'
                      }>•</span>
                      <span>Test your solution thoroughly before submission</span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <span className={
                        config.color === 'emerald' ? 'text-emerald-400'
                          : config.color === 'amber' ? 'text-amber-400'
                          : 'text-rose-400'
                      }>•</span>
                      <span>Submit your work as a compressed file (.zip)</span>
                    </li>
                  </ul>
                </div>
              </div>

              {/* File Upload */}
              <div className="border-2 border-dashed border-slate-700 rounded-2xl p-8 text-center hover:border-slate-600 transition-colors">
                <Upload className="w-12 h-12 mx-auto mb-4 text-slate-500" />
                <div className="text-slate-300 mb-2">
                  {file ? file.name : 'Drop your project files here or click to browse'}
                </div>
                <input
                  type="file"
                  onChange={(e) => setFile(e.target.files[0])}
                  className="hidden"
                  id="file-upload"
                />
                <label
                  htmlFor="file-upload"
                  className="inline-block px-6 py-3 bg-slate-800 hover:bg-slate-700 text-white rounded-xl cursor-pointer transition-colors"
                >
                  Choose File
                </label>
              </div>

              <div className="flex items-start space-x-3 bg-rose-500/10 border border-rose-500/30 rounded-xl p-4">
                <AlertCircle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-rose-200">
                  <strong>Deadline Warning:</strong> You have {session.timeRemaining} hours remaining. 
                  Submissions after the deadline will receive a score of 0.
                </div>
              </div>

              <button
                onClick={() => alert('Task submitted successfully!')}
                disabled={!file}
                className={`w-full py-4 rounded-xl font-semibold transition-all ${
                  !file
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                    : config.color === 'emerald'
                    ? 'bg-emerald-500 text-white hover:bg-emerald-600'
                    : config.color === 'amber'
                    ? 'bg-amber-500 text-white hover:bg-amber-600'
                    : 'bg-rose-500 text-white hover:bg-rose-600'
                }`}
              >
                Submit Task
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// Step Component for Progress
function Step({ number, label, active, completed, color, disabled }) {
  return (
    <div className="flex items-center space-x-3">
      <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold transition-all ${
        completed
          ? color === 'emerald' ? 'bg-emerald-500 text-white'
            : color === 'amber' ? 'bg-amber-500 text-white'
            : 'bg-rose-500 text-white'
          : active && !disabled
          ? color === 'emerald' ? 'bg-emerald-500/20 text-emerald-400 ring-2 ring-emerald-500'
            : color === 'amber' ? 'bg-amber-500/20 text-amber-400 ring-2 ring-amber-500'
            : 'bg-rose-500/20 text-rose-400 ring-2 ring-rose-500'
          : 'bg-slate-800 text-slate-500'
      }`}>
        {completed ? '✓' : number}
      </div>
      <span className={`font-medium ${
        active || completed ? 'text-white' : 'text-slate-500'
      }`}>
        {label}
      </span>
    </div>
  );
}

// Supervisor Dashboard Component
function SupervisorDashboard({ students, setStudents, onLogout }) {
  const [selectedStudent, setSelectedStudent] = useState(null);

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-slate-900/50 backdrop-blur-xl border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="text-2xl font-bold bg-gradient-to-r from-emerald-400 via-amber-400 to-rose-400 bg-clip-text text-transparent">
              InternHub
            </div>
            <div className="px-3 py-1 rounded-lg text-sm font-semibold bg-purple-500/20 text-purple-400">
              Supervisor
            </div>
          </div>
          <button
            onClick={onLogout}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors"
          >
            Logout
          </button>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Supervisor Dashboard</h2>
          <p className="text-slate-400">Monitor and manage all internship participants</p>
        </div>

        {/* Overview Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="bg-slate-900/50 backdrop-blur-xl rounded-2xl p-6 border border-slate-800">
            <div className="flex items-center space-x-3 mb-2">
              <Users className="w-6 h-6 text-blue-400" />
              <span className="text-sm text-slate-400">Total Students</span>
            </div>
            <div className="text-3xl font-bold text-white">{students.length}</div>
          </div>
          <div className="bg-slate-900/50 backdrop-blur-xl rounded-2xl p-6 border border-slate-800">
            <div className="flex items-center space-x-3 mb-2">
              <TrendingUp className="w-6 h-6 text-emerald-400" />
              <span className="text-sm text-slate-400">Active</span>
            </div>
            <div className="text-3xl font-bold text-white">{students.filter(s => s.paymentConfirmed).length}</div>
          </div>
          <div className="bg-slate-900/50 backdrop-blur-xl rounded-2xl p-6 border border-slate-800">
            <div className="flex items-center space-x-3 mb-2">
              <Award className="w-6 h-6 text-amber-400" />
              <span className="text-sm text-slate-400">Certificates Issued</span>
            </div>
            <div className="text-3xl font-bold text-white">0</div>
          </div>
          <div className="bg-slate-900/50 backdrop-blur-xl rounded-2xl p-6 border border-slate-800">
            <div className="flex items-center space-x-3 mb-2">
              <AlertCircle className="w-6 h-6 text-rose-400" />
              <span className="text-sm text-slate-400">Pending Reviews</span>
            </div>
            <div className="text-3xl font-bold text-white">3</div>
          </div>
        </div>

        {/* Students Table */}
        <div className="bg-slate-900/50 backdrop-blur-xl rounded-2xl border border-slate-800 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-800">
            <h3 className="font-semibold text-white">All Students</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-800/50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase">Student</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase">Level</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase">Progress</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase">Started</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase">Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {students.map((student) => (
                  <tr key={student.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="px-6 py-4">
                      <div>
                        <div className="font-medium text-white">{student.firstName} {student.lastName}</div>
                        <div className="text-sm text-slate-400">{student.email}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 rounded text-sm font-semibold ${
                        student.level === 'L3' ? 'bg-emerald-500/20 text-emerald-400'
                          : student.level === 'L4' ? 'bg-amber-500/20 text-amber-400'
                          : 'bg-rose-500/20 text-rose-400'
                      }`}>
                        {student.level}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-2">
                        <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-emerald-500"
                            style={{ width: `${(student.completedSessions / 10) * 100}%` }}
                          />
                        </div>
                        <span className="text-sm text-slate-400">{student.completedSessions}/10</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-400">
                      {new Date(student.internshipStartDate).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 rounded text-sm font-semibold ${
                        student.paymentConfirmed
                          ? 'bg-green-500/20 text-green-400'
                          : 'bg-amber-500/20 text-amber-400'
                      }`}>
                        {student.paymentConfirmed ? 'Active' : 'Pending'}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <button
                        onClick={() => setSelectedStudent(student)}
                        className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm transition-colors"
                      >
                        View Details
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Student Detail Modal */}
      {selectedStudent && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="w-full max-w-4xl bg-slate-900 rounded-3xl border border-slate-800 max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-slate-900 border-b border-slate-800 px-8 py-6 flex items-center justify-between">
              <div>
                <h3 className="text-2xl font-bold text-white">
                  {selectedStudent.firstName} {selectedStudent.lastName}
                </h3>
                <p className="text-slate-400 mt-1">{selectedStudent.email}</p>
              </div>
              <button
                onClick={() => setSelectedStudent(null)}
                className="w-10 h-10 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 transition-colors"
              >
                ×
              </button>
            </div>
            <div className="p-8 space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
                  <div className="text-sm text-slate-400 mb-1">School</div>
                  <div className="font-medium text-white">{selectedStudent.school}</div>
                </div>
                <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
                  <div className="text-sm text-slate-400 mb-1">Level</div>
                  <div className="font-medium text-white">{selectedStudent.level}</div>
                </div>
              </div>
              
              <div className="space-y-3">
                <h4 className="font-semibold text-white">Session Progress</h4>
                {selectedStudent.sessions.slice(0, 5).map((session) => (
                  <div key={session.id} className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
                    <div className="flex items-center justify-between">
                      <span className="text-white">{session.title}</span>
                      <span className={`px-2 py-1 rounded text-sm ${
                        session.submitted ? 'bg-emerald-500/20 text-emerald-400'
                          : session.taskUnlocked ? 'bg-blue-500/20 text-blue-400'
                          : 'bg-slate-700 text-slate-400'
                      }`}>
                        {session.submitted ? `Completed (${session.score})` : session.taskUnlocked ? 'In Progress' : 'Locked'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex space-x-4">
                <button className="flex-1 py-3 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl font-semibold transition-colors">
                  Approve Certificate
                </button>
                <button className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-semibold transition-colors">
                  Extend Deadline
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}