/**
 * Authentication Service
 * Handles all authentication-related API calls
 */

import { post } from '../utils/api';
import { API_ENDPOINTS } from '../constants/apiConfig';

export const authService = {
  /**
   * Login user
   */
  async login(email, password) {
    try {
      const result = await post(API_ENDPOINTS.LOGIN, { email, password });
      
      if (result.success) {
        const { token, refreshToken, user } = result.data;
        
        // Store auth data
        localStorage.setItem('authToken', token);
        localStorage.setItem('refreshToken', refreshToken);
        localStorage.setItem('userData', JSON.stringify(user));
        
        return { success: true, data: { token, user } };
      }
      
      return { success: false, error: result.error };
    } catch (error) {
      return { success: false, error: 'Login failed. Please try again.' };
    }
  },

  /**
   * Register new user
   */
  async register(userData) {
    try {
      const result = await post(API_ENDPOINTS.REGISTER, userData);
      return result;
    } catch (error) {
      return { success: false, error: 'Registration failed. Please try again.' };
    }
  },

  /**
   * Logout user
   */
  logout() {
    localStorage.removeItem('authToken');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('userData');
  },

  /**
   * Get current user data
   */
  getCurrentUser() {
    try {
      const userData = localStorage.getItem('userData');
      return userData ? JSON.parse(userData) : null;
    } catch (error) {
      return null;
    }
  },

  /**
   * Check if user is authenticated
   */
  isAuthenticated() {
    return !!localStorage.getItem('authToken');
  },

  /**
   * Verify email
   */
  async verifyEmail(token) {
    try {
      const result = await post(API_ENDPOINTS.VERIFY_EMAIL, { token });
      return result;
    } catch (error) {
      return { success: false, error: 'Email verification failed.' };
    }
  }
};
