/**
 * Student Routes
 * Routes for student-specific operations
 */

const express = require('express');
const router = express.Router();
const StudentController = require('../controllers/studentController');
const { authenticate, authorize } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

// All routes require authentication and student role
router.use(authenticate);
router.use(authorize('student'));

// Dashboard and enrollment
router.get('/dashboard', asyncHandler(StudentController.getDashboard));
router.post('/enroll', asyncHandler(StudentController.enrollInLevel));

// Level and session access
router.get('/levels/:levelId', asyncHandler(StudentController.getLevelDetails));

// Task operations
router.post('/tasks/:taskId/read', asyncHandler(StudentController.markMaterialRead));
router.post('/tasks/:taskId/submit', asyncHandler(StudentController.submitTask));
router.post('/tasks/:taskId/recovery', asyncHandler(StudentController.requestRecovery));

// Submissions
router.get('/submissions', asyncHandler(StudentController.getMySubmissions));

module.exports = router;
