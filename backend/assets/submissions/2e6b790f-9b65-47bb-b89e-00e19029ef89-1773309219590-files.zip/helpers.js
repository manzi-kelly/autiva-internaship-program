import { format, differenceInDays, differenceInHours, isAfter, isBefore } from 'date-fns';

export const formatDate = (date, formatStr = 'MMM dd, yyyy') => {
  if (!date) return '';
  return format(new Date(date), formatStr);
};

export const getDaysActive = (startDate) => {
  if (!startDate) return 0;
  return differenceInDays(new Date(), new Date(startDate));
};

export const getHoursRemaining = (deadline) => {
  if (!deadline) return 0;
  const hours = differenceInHours(new Date(deadline), new Date());
  return Math.max(0, hours);
};

export const isDeadlinePassed = (deadline) => {
  return isAfter(new Date(), new Date(deadline));
};

export const calculateProgress = (completed, total) => {
  if (!total || total === 0) return 0;
  return Math.round((completed / total) * 100);
};

export const getSessionStatus = (session) => {
  if (!session.documentRead) return 'locked';
  if (session.submitted) return 'completed';
  if (session.taskUnlocked) return 'in_progress';
  return 'document_reading';
};

export const canSubmitTask = (session) => {
  return session.documentRead && session.taskUnlocked && !session.submitted;
};

export const isEligibleForCertificate = (student, levelConfig) => {
  const config = levelConfig[student.level];
  if (!config) return false;
  return student.completedSessions >= config.passingRequirement;
};

export const getStatusColor = (status) => {
  const colors = {
    locked: 'slate',
    document_reading: 'blue',
    in_progress: 'amber',
    completed: 'emerald',
    failed: 'rose',
    pending: 'amber',
    active: 'emerald'
  };
  return colors[status] || 'slate';
};

export const formatFileSize = (bytes) => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
};

export const validateEmail = (email) => {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
};

export const validatePassword = (password) => {
  return password.length >= 8;
};

export const truncateText = (text, maxLength) => {
  if (!text || text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
};
