# 🚀 Setup Guide

## Quick Start (5 minutes)

### 1. Install Dependencies
```bash
cd internship-management-system
npm install
```

### 2. Configure Environment
```bash
cp .env.example .env
# Edit .env with your API URL
```

### 3. Start Development Server
```bash
npm run dev
```

Application opens at `http://localhost:3000`

## Production Build

```bash
npm run build      # Creates /dist folder
npm run preview    # Preview production build
```

## Project Features

✅ **Fully Configured**
- Vite + React 18
- Tailwind CSS with custom theme
- React Router 6
- API utility with Axios
- Authentication context
- Level-based system (L3/L4/L5)

✅ **Pages Included**
- Login/Register
- Payment
- Student Dashboard
- Supervisor Dashboard
- 404 Not Found

✅ **Ready for Backend Integration**
- API endpoints defined in `src/constants/apiConfig.js`
- JWT auth flow implemented
- File upload utilities ready
- Request interceptors configured

## Next Development Steps

1. **Build Components** - Create components in `/src/components/`
2. **Connect Backend** - Update API_BASE_URL in `.env`
3. **Add Real Data** - Replace mock data with API calls
4. **Implement Sessions** - Build session management UI
5. **Add File Upload** - Complete task submission feature
6. **Testing** - Add unit and integration tests

## File Structure

```
src/
├── components/      # React components (to build)
├── pages/          # Page components (ready)
├── contexts/       # State management (configured)
├── utils/          # Helper functions (ready)
├── constants/      # Configurations (ready)
└── hooks/          # Custom hooks (to build)
```

## Key Configuration Files

- `vite.config.js` - Build config with path aliases
- `tailwind.config.js` - Custom colors & animations
- `src/constants/levelConfig.js` - Level system setup
- `src/utils/api.js` - API request handlers

## Development Tips

1. Use `@` aliases for imports: `import { api } from '@utils/api'`
2. Level colors: L3=emerald, L4=amber, L5=rose
3. All dates use `date-fns` library
4. API calls return `{success, data/error}` format

## Troubleshooting

**Port already in use?**
```bash
# Change port in vite.config.js or:
npm run dev -- --port 3001
```

**Build errors?**
```bash
rm -rf node_modules package-lock.json
npm install
```

## Support

Check `README.md` for full documentation
See `PROJECT_STRUCTURE.md` for architecture details

Happy coding! 🎉
