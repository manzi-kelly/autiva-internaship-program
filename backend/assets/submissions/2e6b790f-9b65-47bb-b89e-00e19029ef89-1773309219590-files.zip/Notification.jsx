import React, { useEffect } from 'react';
import { CheckCircle, AlertCircle, Info, X, AlertTriangle } from 'lucide-react';

export default function Notification({ type = 'info', message, onClose, duration = 5000 }) {
  useEffect(() => {
    if (duration && onClose) {
      const timer = setTimeout(onClose, duration);
      return () => clearTimeout(timer);
    }
  }, [duration, onClose]);

  const types = {
    success: { icon: CheckCircle, bg: 'bg-emerald-500/20', border: 'border-emerald-500', text: 'text-emerald-400' },
    error: { icon: AlertCircle, bg: 'bg-rose-500/20', border: 'border-rose-500', text: 'text-rose-400' },
    warning: { icon: AlertTriangle, bg: 'bg-amber-500/20', border: 'border-amber-500', text: 'text-amber-400' },
    info: { icon: Info, bg: 'bg-blue-500/20', border: 'border-blue-500', text: 'text-blue-400' },
  };

  const config = types[type];
  const Icon = config.icon;

  return (
    <div className={`${config.bg} border ${config.border} rounded-xl p-4 flex items-start space-x-3 animate-slide-down`}>
      <Icon className={`w-5 h-5 ${config.text} flex-shrink-0 mt-0.5`} />
      <p className={`flex-1 text-sm ${config.text}`}>{message}</p>
      {onClose && (
        <button onClick={onClose} className={`${config.text} hover:opacity-70 transition-opacity`}>
          <X className="w-4 h-4" />
        </button>
      )}
    </div>
  );
}

export function NotificationContainer({ notifications = [] }) {
  return (
    <div className="fixed top-4 right-4 z-50 space-y-3 max-w-md">
      {notifications.map((notif) => (
        <Notification key={notif.id} {...notif} />
      ))}
    </div>
  );
}
