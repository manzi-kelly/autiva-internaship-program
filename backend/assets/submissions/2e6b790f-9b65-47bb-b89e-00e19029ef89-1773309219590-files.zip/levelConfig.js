/**
 * Level Configuration Constants
 * Defines the structure, requirements, and characteristics for each internship level
 */

export const LEVEL_CONFIG = {
  L3: {
    id: 'L3',
    name: 'Level 3 - Frontend Fundamentals',
    color: 'emerald',
    colorClasses: {
      bg: 'bg-emerald-500',
      bgLight: 'bg-emerald-500/20',
      text: 'text-emerald-400',
      border: 'border-emerald-500',
      hover: 'hover:bg-emerald-600',
      gradient: 'from-emerald-500 to-emerald-600'
    },
    sessions: 10,
    deadline: 8, // hours per session
    focus: ['HTML', 'CSS', 'Web Layout Design'],
    passingRequirement: 8,
    description: 'Master the fundamentals of web development with HTML and CSS',
    sessionTitles: [
      'HTML Basics & Structure',
      'CSS Fundamentals',
      'Advanced Layout Design',
      'Responsive Web Design',
      'Forms & Input Handling',
      'CSS Grid Mastery',
      'Flexbox Advanced Techniques',
      'CSS Animations & Transitions',
      'Web Accessibility Standards',
      'Final Portfolio Project'
    ]
  },
  L4: {
    id: 'L4',
    name: 'Level 4 - Backend Development',
    color: 'amber',
    colorClasses: {
      bg: 'bg-amber-500',
      bgLight: 'bg-amber-500/20',
      text: 'text-amber-400',
      border: 'border-amber-500',
      hover: 'hover:bg-amber-600',
      gradient: 'from-amber-500 to-amber-600'
    },
    sessions: 5,
    deadline: 10, // hours per session
    focus: ['MySQL', 'PHP', 'Node.js'],
    passingRequirement: 4,
    description: 'Build robust backend systems with databases and server-side logic',
    sessionTitles: [
      'MySQL Database Design',
      'SQL Queries & Optimization',
      'PHP Backend Fundamentals',
      'Node.js & Express.js',
      'API Development & Integration'
    ]
  },
  L5: {
    id: 'L5',
    name: 'Level 5 - Full-Stack Architecture',
    color: 'rose',
    colorClasses: {
      bg: 'bg-rose-500',
      bgLight: 'bg-rose-500/20',
      text: 'text-rose-400',
      border: 'border-rose-500',
      hover: 'hover:bg-rose-600',
      gradient: 'from-rose-500 to-rose-600'
    },
    sessions: 3,
    deadline: 48, // hours per project
    focus: ['React.js', 'CRUD Operations', 'Database Integration'],
    passingRequirement: 3,
    description: 'Create complete full-stack applications with modern frameworks',
    sessionTitles: [
      'National-Level Exam Project 1',
      'National-Level Exam Project 2',
      'Capstone Full-Stack Project'
    ],
    isCapstone: true
  }
};

export const SESSION_STATUS = {
  LOCKED: 'locked',
  DOCUMENT_READING: 'document_reading',
  TASK_UNLOCKED: 'task_unlocked',
  IN_PROGRESS: 'in_progress',
  SUBMITTED: 'submitted',
  GRADED: 'graded',
  FAILED: 'failed'
};

export const USER_ROLES = {
  STUDENT: 'student',
  SUPERVISOR: 'supervisor',
  ADMIN: 'admin'
};

export const PAYMENT_STATUS = {
  PENDING: 'pending',
  PROCESSING: 'processing',
  COMPLETED: 'completed',
  FAILED: 'failed',
  REFUNDED: 'refunded'
};

export const REGISTRATION_FEE = 299; // USD

export const CERTIFICATE_REQUIREMENTS = {
  L3: {
    minSessions: 8,
    minScore: 60,
    description: 'Complete at least 8 out of 10 sessions with passing scores'
  },
  L4: {
    minSessions: 4,
    minScore: 65,
    description: 'Complete at least 4 out of 5 sessions with passing scores'
  },
  L5: {
    minSessions: 3,
    minScore: 70,
    description: 'Complete all 3 projects with passing scores'
  }
};

export const RECOVERY_POLICY = {
  fee: 50, // USD
  allowExplanation: true,
  supervisorApprovalRequired: true,
  maxRecoveries: 2 // per student
};
