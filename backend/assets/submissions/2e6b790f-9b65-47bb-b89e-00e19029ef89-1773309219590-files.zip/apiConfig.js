/**
 * API Configuration
 * Base URLs and endpoints for backend communication
 */

export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api';

export const API_ENDPOINTS = {
  // Authentication
  LOGIN: '/auth/login',
  REGISTER: '/auth/register',
  LOGOUT: '/auth/logout',
  REFRESH_TOKEN: '/auth/refresh',
  VERIFY_EMAIL: '/auth/verify-email',
  
  // Students
  STUDENT_PROFILE: '/students/profile',
  STUDENT_SESSIONS: '/students/sessions',
  STUDENT_PROGRESS: '/students/progress',
  UPDATE_PROFILE: '/students/update',
  
  // Sessions
  GET_SESSION: '/sessions/:id',
  READ_DOCUMENT: '/sessions/:id/read-document',
  UNLOCK_TASK: '/sessions/:id/unlock-task',
  SUBMIT_TASK: '/sessions/:id/submit',
  GET_SUBMISSION: '/sessions/:id/submission',
  
  // Payments
  PROCESS_PAYMENT: '/payments/process',
  VERIFY_PAYMENT: '/payments/verify',
  PAYMENT_HISTORY: '/payments/history',
  
  // Supervisor
  GET_ALL_STUDENTS: '/supervisor/students',
  GET_STUDENT_DETAILS: '/supervisor/students/:id',
  APPROVE_RECOVERY: '/supervisor/students/:id/approve-recovery',
  EXTEND_DEADLINE: '/supervisor/students/:id/extend-deadline',
  REOPEN_SESSION: '/supervisor/students/:id/sessions/:sessionId/reopen',
  APPROVE_CERTIFICATE: '/supervisor/students/:id/approve-certificate',
  
  // Certificates
  GENERATE_CERTIFICATE: '/certificates/generate',
  GET_CERTIFICATE: '/certificates/:id',
  VERIFY_CERTIFICATE: '/certificates/verify/:certificateId',
  
  // Analytics
  STUDENT_ANALYTICS: '/analytics/student',
  SYSTEM_ANALYTICS: '/analytics/system',
};

export const HTTP_METHODS = {
  GET: 'GET',
  POST: 'POST',
  PUT: 'PUT',
  PATCH: 'PATCH',
  DELETE: 'DELETE'
};

export const REQUEST_TIMEOUT = 30000; // 30 seconds
