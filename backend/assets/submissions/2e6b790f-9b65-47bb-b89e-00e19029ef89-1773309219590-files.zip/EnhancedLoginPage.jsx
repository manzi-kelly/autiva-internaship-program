import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Button, Input, Alert } from '../components';
import { Lock, Mail, BookOpen, Timer, Award } from 'lucide-react';

export default function EnhancedLoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const result = await login(email, password);
    
    if (result.success) {
      navigate('/dashboard');
    } else {
      setError(result.error || 'Invalid email or password');
    }
    
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900 p-4">
      <div className="w-full max-w-6xl grid md:grid-cols-2 gap-8">
        {/* Left Side - Branding */}
        <div className="flex flex-col justify-center space-y-6 text-white">
          <div className="space-y-4">
            <div className="inline-block">
              <div className="text-6xl font-bold bg-gradient-to-r from-emerald-400 via-amber-400 to-rose-400 bg-clip-text text-transparent animate-fade-in">
                InternHub
              </div>
            </div>
            <h2 className="text-3xl font-bold">Professional Internship Training</h2>
            <p className="text-slate-300 text-lg leading-relaxed">
              Master web development through structured, hands-on internship programs designed for all skill levels.
            </p>
          </div>
          
          <div className="space-y-4">
            <FeatureItem
              icon={BookOpen}
              title="Level-Based Learning"
              description="Structured curriculum from HTML/CSS to Full-Stack Development"
              color="emerald"
            />
            
            <FeatureItem
              icon={Timer}
              title="Time-Tracked Sessions"
              description="Complete practical tasks within deadlines to build discipline"
              color="amber"
            />
            
            <FeatureItem
              icon={Award}
              title="Certificate Recognition"
              description="Earn industry-recognized certificates upon completion"
              color="rose"
            />
          </div>

          {/* Demo Credentials */}
          <div className="mt-8 p-4 bg-slate-800/50 border border-slate-700 rounded-xl">
            <p className="text-sm text-slate-400 mb-2">Demo Credentials:</p>
            <div className="space-y-1 text-sm">
              <div className="text-slate-300">
                <span className="text-slate-500">Student:</span> student@demo.com / password
              </div>
              <div className="text-slate-300">
                <span className="text-slate-500">Supervisor:</span> supervisor@demo.com / password
              </div>
            </div>
          </div>
        </div>

        {/* Right Side - Login Form */}
        <div className="bg-slate-900/50 backdrop-blur-xl rounded-3xl p-8 border border-slate-800 shadow-2xl">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-white mb-2">Welcome Back</h2>
            <p className="text-slate-400">Sign in to continue your internship journey</p>
          </div>

          {error && (
            <Alert type="error" className="mb-6" onClose={() => setError('')}>
              {error}
            </Alert>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <Input
              label="Email Address"
              type="email"
              icon={Mail}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              required
            />

            <Input
              label="Password"
              type="password"
              icon={Lock}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              required
            />

            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center space-x-2 text-slate-400 cursor-pointer">
                <input type="checkbox" className="rounded" />
                <span>Remember me</span>
              </label>
              <a href="#" className="text-emerald-400 hover:text-emerald-300 transition-colors">
                Forgot password?
              </a>
            </div>

            <Button
              type="submit"
              variant="primary"
              loading={loading}
              fullWidth
              size="lg"
            >
              Sign In
            </Button>
          </form>

          <div className="mt-8 text-center">
            <p className="text-slate-400">
              Don't have an account?{' '}
              <Link to="/register" className="text-emerald-400 hover:text-emerald-300 font-semibold transition-colors">
                Create Account
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function FeatureItem({ icon: Icon, title, description, color }) {
  const colors = {
    emerald: 'bg-emerald-500/20 text-emerald-400',
    amber: 'bg-amber-500/20 text-amber-400',
    rose: 'bg-rose-500/20 text-rose-400',
  };

  return (
    <div className="flex items-start space-x-4">
      <div className={`w-12 h-12 rounded-xl ${colors[color]} flex items-center justify-center flex-shrink-0`}>
        <Icon className="w-6 h-6" />
      </div>
      <div>
        <h3 className="font-semibold text-lg mb-1">{title}</h3>
        <p className="text-slate-400 text-sm leading-relaxed">{description}</p>
      </div>
    </div>
  );
}
