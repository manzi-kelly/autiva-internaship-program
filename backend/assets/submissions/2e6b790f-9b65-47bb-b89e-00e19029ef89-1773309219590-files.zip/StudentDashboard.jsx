import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import {
  StatCard, ProgressBar, LevelInfo, SessionCard,
  SessionModal, Button, Loader
} from '../components';
import { Calendar, CheckCircle, TrendingUp, Award, LogOut } from 'lucide-react';
import { useSession, useNotification } from '../hooks';
import { LEVEL_CONFIG } from '../constants/levelConfig';
import { getDaysActive, calculateProgress } from '../utils/helpers';

export default function StudentDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { markDocumentAsRead, submitTask, loading: sessionLoading } = useSession();
  const notify = useNotification();
  
  const [selectedSession, setSelectedSession] = useState(null);
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);

  const config = LEVEL_CONFIG[user?.level || 'L3'];
  
  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    setLoading(true);
    // Simulate API call - replace with real API
    setTimeout(() => {
      setSessions(generateMockSessions(config.sessions, config.sessionTitles));
      setLoading(false);
    }, 1000);
  };

  const handleDocumentRead = async (sessionId) => {
    const result = await markDocumentAsRead(sessionId);
    if (result.success) {
      notify.success('Document marked as read! Task unlocked.');
      // Update local state
      setSessions(prev => prev.map(s => 
        s.id === sessionId ? { ...s, documentRead: true, taskUnlocked: true } : s
      ));
    } else {
      notify.error(result.error || 'Failed to mark document as read');
    }
  };

  const handleTaskSubmit = async (sessionId, file) => {
    const result = await submitTask(sessionId, file);
    if (result.success) {
      notify.success('Task submitted successfully! Awaiting grading.');
      setSelectedSession(null);
      // Update local state
      setSessions(prev => prev.map(s => 
        s.id === sessionId ? { ...s, submitted: true, score: 0 } : s
      ));
    } else {
      notify.error(result.error || 'Failed to submit task');
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900">
        <Loader size="lg" text="Loading your dashboard..." />
      </div>
    );
  }

  const completedSessions = sessions.filter(s => s.submitted).length;
  const progress = calculateProgress(completedSessions, config.sessions);
  const daysActive = getDaysActive(user?.internshipStartDate || new Date());
  const isEligibleForCertificate = completedSessions >= config.passingRequirement;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900">
      {/* Header */}
      <header className="bg-slate-900/50 backdrop-blur-xl border-b border-slate-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="text-2xl font-bold bg-gradient-to-r from-emerald-400 via-amber-400 to-rose-400 bg-clip-text text-transparent">
              InternHub
            </div>
            <div className={`px-3 py-1 rounded-lg text-sm font-semibold ${config.colorClasses.bgLight} ${config.colorClasses.text}`}>
              {user?.level}
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right hidden md:block">
              <div className="text-sm text-slate-400">Welcome back,</div>
              <div className="font-semibold text-white">{user?.firstName} {user?.lastName}</div>
            </div>
            <Button variant="ghost" size="sm" icon={LogOut} onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Welcome Message */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">
            Welcome back, {user?.firstName}! 👋
          </h1>
          <p className="text-slate-400">
            You're making great progress. Keep up the excellent work!
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            icon={Calendar}
            label="Days Active"
            value={daysActive}
            color={config.color}
          />
          <StatCard
            icon={CheckCircle}
            label="Sessions Completed"
            value={`${completedSessions}/${config.sessions}`}
            color={config.color}
          />
          <StatCard
            icon={TrendingUp}
            label="Overall Progress"
            value={`${Math.round(progress)}%`}
            color={config.color}
            trend={progress > 50 ? 'up' : undefined}
            trendValue={progress > 50 ? `${Math.round(progress - 50)}%` : undefined}
          />
          <StatCard
            icon={Award}
            label="Certificate Status"
            value={isEligibleForCertificate ? 'Eligible' : 'In Progress'}
            color={isEligibleForCertificate ? 'emerald' : 'amber'}
          />
        </div>

        {/* Progress Section */}
        <div className="bg-slate-900/50 backdrop-blur-xl rounded-2xl p-6 border border-slate-800 mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-semibold text-white text-lg">Your Progress</h3>
              <p className="text-sm text-slate-400">
                Complete {config.passingRequirement} sessions to earn your certificate
              </p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-white">{Math.round(progress)}%</div>
              <div className="text-xs text-slate-400">Complete</div>
            </div>
          </div>
          <ProgressBar 
            progress={progress} 
            color={config.color}
            showPercentage={false}
          />
          {isEligibleForCertificate && (
            <div className="mt-4 p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl">
              <p className="text-emerald-400 font-medium">
                🎉 Congratulations! You're eligible for your certificate. Complete remaining sessions to finalize.
              </p>
            </div>
          )}
        </div>

        {/* Level Information */}
        <div className="mb-8">
          <LevelInfo level={user?.level || 'L3'} />
        </div>

        {/* Sessions Section */}
        <div className="space-y-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-white">Your Sessions</h2>
            <div className="text-sm text-slate-400">
              {completedSessions} of {config.sessions} completed
            </div>
          </div>

          {sessions.length === 0 ? (
            <div className="bg-slate-900/50 backdrop-blur-xl rounded-2xl p-12 border border-slate-800 text-center">
              <p className="text-slate-400">No sessions available yet.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {sessions.map((session) => (
                <SessionCard
                  key={session.id}
                  session={session}
                  level={user?.level || 'L3'}
                  onClick={() => setSelectedSession(session)}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Session Modal */}
      {selectedSession && (
        <SessionModal
          session={selectedSession}
          level={user?.level || 'L3'}
          isOpen={!!selectedSession}
          onClose={() => setSelectedSession(null)}
          onDocumentRead={handleDocumentRead}
          onTaskSubmit={handleTaskSubmit}
        />
      )}
    </div>
  );
}

// Helper function to generate mock sessions
function generateMockSessions(count, titles) {
  return Array.from({ length: count }, (_, i) => ({
    id: i + 1,
    title: titles?.[i] || `Session ${i + 1}`,
    documentRead: i < 3,
    taskUnlocked: i < 3,
    submitted: i < 2,
    score: i < 2 ? 85 + (i * 5) : 0,
    deadline: 8,
    timeRemaining: i === 2 ? 4.5 : i > 2 ? 8 : 0
  }));
}
