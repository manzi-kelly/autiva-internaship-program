/**
 * Submission Model
 * Handles all database operations related to task submissions
 */

const db = require('../config/database');

class SubmissionModel {
  /**
   * Get all submissions for a user
   * @param {number} userId - User ID
   * @param {string} levelId - Optional level filter
   * @returns {Promise<Array>} List of submissions
   */
  static async getUserSubmissions(userId, levelId = null) {
    let query = `
      SELECT 
        sub.*,
        s.session_number,
        s.session_title,
        s.level_id,
        t.task_title,
        t.task_description,
        t.max_score,
        CASE 
          WHEN sub.deadline < CURRENT_TIMESTAMP AND sub.status = 'not_started' THEN true
          WHEN sub.deadline < CURRENT_TIMESTAMP AND sub.status = 'reading' THEN true
          WHEN sub.deadline < CURRENT_TIMESTAMP AND sub.status = 'in_progress' THEN true
          ELSE false
        END as is_overdue
      FROM submissions sub
      JOIN tasks t ON sub.task_id = t.task_id
      JOIN sessions s ON sub.session_id = s.session_id
      WHERE sub.user_id = $1
    `;
    
    const params = [userId];
    
    if (levelId) {
      query += ' AND s.level_id = $2';
      params.push(levelId);
    }
    
    query += ' ORDER BY s.session_number, t.task_id';
    
    const result = await db.query(query, params);
    return result.rows;
  }

  /**
   * Mark reading material as read
   * @param {number} userId - User ID
   * @param {number} taskId - Task ID
   * @returns {Promise<Object>} Updated submission
   */
  static async markMaterialRead(userId, taskId) {
    const query = `
      UPDATE submissions
      SET has_read_material = true,
          material_read_at = CURRENT_TIMESTAMP,
          task_unlocked_at = CURRENT_TIMESTAMP,
          status = 'in_progress'
      WHERE user_id = $1 AND task_id = $2
      RETURNING *
    `;
    
    const result = await db.query(query, [userId, taskId]);
    return result.rows[0];
  }

  /**
   * Submit a task
   * @param {number} userId - User ID
   * @param {number} taskId - Task ID
   * @param {Object} submissionData - Submission content
   * @returns {Promise<Object>} Updated submission
   */
  static async submitTask(userId, taskId, submissionData) {
    const { content, fileUrl, githubUrl, demoUrl } = submissionData;
    
    const query = `
      UPDATE submissions
      SET submission_content = $1,
          submission_file_url = $2,
          github_url = $3,
          demo_url = $4,
          submitted_at = CURRENT_TIMESTAMP,
          is_late = CASE WHEN CURRENT_TIMESTAMP > deadline THEN true ELSE false END,
          status = 'submitted'
      WHERE user_id = $5 AND task_id = $6
      RETURNING *
    `;
    
    const result = await db.query(query, [
      content, fileUrl, githubUrl, demoUrl, userId, taskId
    ]);
    
    // If submission is late and not already failed, set score to 0
    if (result.rows[0].is_late) {
      await db.query(
        'UPDATE submissions SET score = 0, status = $1 WHERE user_id = $2 AND task_id = $3',
        ['failed', userId, taskId]
      );
    }
    
    return result.rows[0];
  }

  /**
   * Grade a submission
   * @param {number} submissionId - Submission ID
   * @param {number} score - Score (0-100)
   * @param {string} feedback - Grading feedback
   * @param {number} gradedBy - Supervisor user ID
   * @returns {Promise<Object>} Updated submission
   */
  static async gradeSubmission(submissionId, score, feedback, gradedBy) {
    const client = await db.getClient();
    
    try {
      await client.query('BEGIN');
      
      // Update submission
      const submissionQuery = `
        UPDATE submissions
        SET score = $1,
            feedback = $2,
            graded_by = $3,
            graded_at = CURRENT_TIMESTAMP,
            status = 'graded'
        WHERE submission_id = $4
        RETURNING *
      `;
      
      const submissionResult = await client.query(submissionQuery, [
        score, feedback, gradedBy, submissionId
      ]);
      
      const submission = submissionResult.rows[0];
      
      // Update student progress
      const passThreshold = 50; // 50% to pass
      const isPassed = score >= passThreshold;
      
      const progressQuery = `
        UPDATE student_progress
        SET completed_sessions = completed_sessions + CASE WHEN $1 THEN 1 ELSE 0 END,
            failed_sessions = failed_sessions + CASE WHEN $1 THEN 0 ELSE 1 END,
            total_score = total_score + $2
        WHERE user_id = $3
        AND level_id = (SELECT level_id FROM sessions WHERE session_id = $4)
      `;
      
      await client.query(progressQuery, [
        isPassed, score, submission.user_id, submission.session_id
      ]);
      
      await client.query('COMMIT');
      
      return submission;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Request recovery/makeup for failed submission
   * @param {number} userId - User ID
   * @param {number} taskId - Task ID
   * @param {string} reason - Recovery reason
   * @returns {Promise<Object>} Updated submission
   */
  static async requestRecovery(userId, taskId, reason) {
    const query = `
      UPDATE submissions
      SET recovery_requested = true,
          recovery_reason = $1
      WHERE user_id = $2 AND task_id = $3
      RETURNING *
    `;
    
    const result = await db.query(query, [reason, userId, taskId]);
    return result.rows[0];
  }

  /**
   * Approve recovery request
   * @param {number} submissionId - Submission ID
   * @param {number} approvedBy - Supervisor user ID
   * @param {number} extensionHours - Hours to extend deadline
   * @returns {Promise<Object>} Updated submission
   */
  static async approveRecovery(submissionId, approvedBy, extensionHours) {
    const query = `
      UPDATE submissions
      SET recovery_approved = true,
          recovery_approved_by = $1,
          deadline = deadline + ($2 || ' hours')::INTERVAL,
          status = 'in_progress',
          is_late = false
      WHERE submission_id = $3
      RETURNING *
    `;
    
    const result = await db.query(query, [approvedBy, extensionHours, submissionId]);
    return result.rows[0];
  }

  /**
   * Get all pending recovery requests
   * @returns {Promise<Array>} List of recovery requests
   */
  static async getPendingRecoveries() {
    const query = `
      SELECT 
        sub.*,
        u.first_name,
        u.last_name,
        u.email,
        t.task_title,
        s.session_title,
        s.level_id
      FROM submissions sub
      JOIN users u ON sub.user_id = u.user_id
      JOIN tasks t ON sub.task_id = t.task_id
      JOIN sessions s ON sub.session_id = s.session_id
      WHERE sub.recovery_requested = true
        AND sub.recovery_approved = false
      ORDER BY sub.created_at DESC
    `;
    
    const result = await db.query(query);
    return result.rows;
  }

  /**
   * Get submission by ID
   * @param {number} submissionId - Submission ID
   * @returns {Promise<Object>} Submission data
   */
  static async getById(submissionId) {
    const query = `
      SELECT 
        sub.*,
        u.first_name,
        u.last_name,
        t.task_title,
        t.task_description,
        s.session_title,
        s.reading_material_content
      FROM submissions sub
      JOIN users u ON sub.user_id = u.user_id
      JOIN tasks t ON sub.task_id = t.task_id
      JOIN sessions s ON sub.session_id = s.session_id
      WHERE sub.submission_id = $1
    `;
    
    const result = await db.query(query, [submissionId]);
    return result.rows[0];
  }
}

module.exports = SubmissionModel;
