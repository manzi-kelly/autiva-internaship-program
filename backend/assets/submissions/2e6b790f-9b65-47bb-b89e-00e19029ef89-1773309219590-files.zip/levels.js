/**
 * Levels Routes
 * Routes for viewing available internship levels
 */

const express = require('express');
const router = express.Router();
const LevelModel = require('../models/Level');
const { asyncHandler } = require('../middleware/errorHandler');

// Get all levels (public)
router.get('/', asyncHandler(async (req, res, next) => {
  const levels = await LevelModel.getAll();
  
  res.json({
    success: true,
    data: { levels }
  });
}));

// Get level by ID with sessions (public)
router.get('/:levelId', asyncHandler(async (req, res, next) => {
  const { levelId } = req.params;
  const level = await LevelModel.getWithSessions(levelId);
  
  if (!level) {
    return res.status(404).json({
      success: false,
      message: 'Level not found'
    });
  }
  
  res.json({
    success: true,
    data: { level }
  });
}));

module.exports = router;
