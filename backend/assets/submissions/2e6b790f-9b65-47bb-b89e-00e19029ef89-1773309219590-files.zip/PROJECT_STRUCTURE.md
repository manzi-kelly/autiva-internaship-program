# Project Structure Documentation

## Directory Organization

### `/src/components/`
Reusable React components organized by feature:

#### `auth/`
- `LoginForm.jsx` - Login form component
- `RegisterForm.jsx` - Registration form with level selection

#### `dashboard/`
- `StatCard.jsx` - Stat display cards (days active, progress, etc.)
- `ProgressBar.jsx` - Progress visualization component
- `LevelInfo.jsx` - Level information display

#### `sessions/`
- `SessionCard.jsx` - Individual session card in list
- `SessionModal.jsx` - Full session details modal
- `DocumentReader.jsx` - Document reading interface
- `TaskSubmission.jsx` - File upload and submission

#### `supervisor/`
- `StudentTable.jsx` - Table of all students
- `StudentDetailModal.jsx` - Individual student details
- `AnalyticsCards.jsx` - System analytics display

#### `common/`
- `Button.jsx` - Reusable button component
- `Modal.jsx` - Base modal component
- `Notification.jsx` - Toast notifications
- `Loader.jsx` - Loading spinner

### `/src/pages/`
Full page components:
- `LoginPage.jsx` - Login screen
- `RegisterPage.jsx` - Registration screen
- `PaymentPage.jsx` - Payment processing
- `StudentDashboard.jsx` - Student main dashboard
- `SupervisorDashboard.jsx` - Supervisor dashboard
- `NotFoundPage.jsx` - 404 error page

### `/src/contexts/`
React Context providers for global state:
- `AuthContext.jsx` - Authentication state (user, login, logout)
- `AppContext.jsx` - Application state (sessions, notifications)

### `/src/utils/`
Utility functions:
- `api.js` - API request handlers (get, post, put, delete)
- `helpers.js` - Helper functions (date formatting, validation)

### `/src/constants/`
Configuration constants:
- `levelConfig.js` - Level definitions (L3/L4/L5)
- `apiConfig.js` - API endpoints and configuration

### `/src/hooks/`
Custom React hooks (to be implemented):
- `useSession.js` - Session management logic
- `useTimer.js` - Countdown timer logic
- `useNotification.js` - Notification system

## Key Files

- `main.jsx` - Application entry point
- `App.jsx` - Main app component with routing
- `index.css` - Global styles with Tailwind
- `vite.config.js` - Vite build configuration
- `tailwind.config.js` - Tailwind customization

## Configuration Files

- `package.json` - Dependencies and scripts
- `.gitignore` - Files to exclude from git
- `.env.example` - Environment variables template
- `postcss.config.js` - PostCSS configuration

## Next Steps for Development

1. **Component Implementation**: Build out component files in `/src/components/`
2. **API Integration**: Connect to backend API endpoints
3. **State Management**: Implement hooks in `/src/hooks/`
4. **Testing**: Add test files alongside components
5. **Documentation**: Add JSDoc comments to functions

## Development Workflow

1. Create feature branch
2. Implement components in appropriate directory
3. Add to relevant page
4. Test functionality
5. Commit and push
6. Create pull request

## Style Guidelines

- Use Tailwind CSS utility classes
- Level-specific colors: L3 (emerald), L4 (amber), L5 (rose)
- Consistent spacing and sizing
- Responsive design (mobile-first)
- Accessible components (ARIA labels)
