import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import {
  StatCard, StudentTable, StudentDetailModal,
  Button, Loader
} from '../components';
import { Users, TrendingUp, Award, AlertCircle, LogOut, Search, Filter } from 'lucide-react';
import { useNotification } from '../hooks';

export default function SupervisorDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const notify = useNotification();
  
  const [students, setStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterLevel, setFilterLevel] = useState('all');

  useEffect(() => {
    loadStudents();
  }, []);

  const loadStudents = async () => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setStudents(generateMockStudents());
      setLoading(false);
    }, 1000);
  };

  const handleApprove = async (studentId) => {
    notify.info('Approving certificate...');
    // Simulate API call
    setTimeout(() => {
      notify.success('Certificate approved successfully!');
      setSelectedStudent(null);
    }, 1500);
  };

  const handleExtend = async (studentId) => {
    notify.info('Extending deadline...');
    // Simulate API call
    setTimeout(() => {
      notify.success('Deadline extended by 24 hours!');
      setSelectedStudent(null);
    }, 1500);
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900">
        <Loader size="lg" text="Loading dashboard..." />
      </div>
    );
  }

  // Calculate statistics
  const totalStudents = students.length;
  const activeStudents = students.filter(s => s.paymentConfirmed).length;
  const certificatesIssued = students.filter(s => s.completedSessions >= 8).length;
  const pendingReviews = students.filter(s => s.sessions?.some(sess => sess.submitted && !sess.graded)).length;

  // Filter students
  const filteredStudents = students.filter(student => {
    const matchesSearch = searchQuery === '' || 
      student.firstName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.lastName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.email.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesLevel = filterLevel === 'all' || student.level === filterLevel;
    
    return matchesSearch && matchesLevel;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900">
      {/* Header */}
      <header className="bg-slate-900/50 backdrop-blur-xl border-b border-slate-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="text-2xl font-bold bg-gradient-to-r from-emerald-400 via-amber-400 to-rose-400 bg-clip-text text-transparent">
              InternHub
            </div>
            <div className="px-3 py-1 rounded-lg text-sm font-semibold bg-purple-500/20 text-purple-400">
              Supervisor
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right hidden md:block">
              <div className="text-sm text-slate-400">Supervisor</div>
              <div className="font-semibold text-white">{user?.firstName} {user?.lastName}</div>
            </div>
            <Button variant="ghost" size="sm" icon={LogOut} onClick={handleLogout}>
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Welcome Message */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">
            Supervisor Dashboard
          </h1>
          <p className="text-slate-400">
            Monitor and manage all internship participants
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            icon={Users}
            label="Total Students"
            value={totalStudents}
            color="blue"
          />
          <StatCard
            icon={TrendingUp}
            label="Active Students"
            value={activeStudents}
            color="emerald"
            trend="up"
            trendValue={`${Math.round((activeStudents/totalStudents)*100)}%`}
          />
          <StatCard
            icon={Award}
            label="Certificates Issued"
            value={certificatesIssued}
            color="amber"
          />
          <StatCard
            icon={AlertCircle}
            label="Pending Reviews"
            value={pendingReviews}
            color="rose"
          />
        </div>

        {/* Filters and Search */}
        <div className="bg-slate-900/50 backdrop-blur-xl rounded-2xl p-6 border border-slate-800 mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            {/* Search */}
            <div className="flex-1 max-w-md">
              <div className="relative">
                <Search className="absolute left-3 top-3 w-5 h-5 text-slate-500" />
                <input
                  type="text"
                  placeholder="Search students..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all"
                />
              </div>
            </div>

            {/* Level Filter */}
            <div className="flex items-center space-x-3">
              <Filter className="w-5 h-5 text-slate-400" />
              <div className="flex space-x-2">
                {['all', 'L3', 'L4', 'L5'].map(level => (
                  <button
                    key={level}
                    onClick={() => setFilterLevel(level)}
                    className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                      filterLevel === level
                        ? 'bg-emerald-500 text-white'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                    }`}
                  >
                    {level === 'all' ? 'All Levels' : level}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Results count */}
          <div className="mt-4 text-sm text-slate-400">
            Showing {filteredStudents.length} of {totalStudents} students
          </div>
        </div>

        {/* Students Table */}
        <StudentTable
          students={filteredStudents}
          onSelectStudent={setSelectedStudent}
        />

        {/* Empty State */}
        {filteredStudents.length === 0 && (
          <div className="bg-slate-900/50 backdrop-blur-xl rounded-2xl p-12 border border-slate-800 text-center mt-8">
            <p className="text-slate-400 mb-4">No students found matching your filters.</p>
            <Button variant="secondary" onClick={() => { setSearchQuery(''); setFilterLevel('all'); }}>
              Clear Filters
            </Button>
          </div>
        )}
      </div>

      {/* Student Detail Modal */}
      {selectedStudent && (
        <StudentDetailModal
          student={selectedStudent}
          isOpen={!!selectedStudent}
          onClose={() => setSelectedStudent(null)}
          onApprove={handleApprove}
          onExtend={handleExtend}
        />
      )}
    </div>
  );
}

// Helper function to generate mock students
function generateMockStudents() {
  const firstNames = ['Alice', 'Bob', 'Charlie', 'Diana', 'Eve', 'Frank', 'Grace', 'Henry'];
  const lastNames = ['Johnson', 'Smith', 'Williams', 'Brown', 'Davis', 'Miller', 'Wilson', 'Moore'];
  const schools = ['Tech University', 'Engineering College', 'Design Institute', 'Business School'];
  const levels = ['L3', 'L4', 'L5'];

  return Array.from({ length: 24 }, (_, i) => ({
    id: i + 1,
    firstName: firstNames[i % firstNames.length],
    lastName: lastNames[Math.floor(i / firstNames.length) % lastNames.length],
    email: `student${i + 1}@example.com`,
    school: schools[i % schools.length],
    level: levels[i % levels.length],
    internshipStartDate: new Date(Date.now() - (Math.random() * 30 * 24 * 60 * 60 * 1000)),
    completedSessions: Math.floor(Math.random() * 10),
    paymentConfirmed: Math.random() > 0.2,
    sessions: Array.from({ length: 10 }, (_, j) => ({
      id: j + 1,
      title: `Session ${j + 1}`,
      submitted: j < Math.floor(Math.random() * 10),
      graded: j < Math.floor(Math.random() * 8),
      score: Math.floor(60 + Math.random() * 40)
    }))
  }));
}
