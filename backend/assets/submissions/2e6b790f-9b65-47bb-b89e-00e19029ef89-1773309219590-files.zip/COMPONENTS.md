# Component Library Documentation

## 📦 Common Components

### Button
**File:** `src/components/common/Button.jsx`

Reusable button with multiple variants and states.

**Props:**
- `variant`: primary | secondary | outline | ghost | danger | success | warning
- `size`: sm | md | lg
- `loading`: boolean - Shows loading spinner
- `disabled`: boolean
- `icon`: Lucide icon component
- `iconPosition`: left | right
- `fullWidth`: boolean

**Usage:**
```jsx
import { Button } from '@components';

<Button variant="primary" loading={isLoading} onClick={handleClick}>
  Submit
</Button>
```

### Modal
**File:** `src/components/common/Modal.jsx`

Accessible modal dialog with backdrop.

**Props:**
- `isOpen`: boolean - Controls visibility
- `onClose`: function - Close handler
- `title`: string - Modal title
- `size`: sm | md | lg | xl
- `showCloseButton`: boolean

### Notification
**File:** `src/components/common/Notification.jsx`

Toast notification system.

**Types:** success | error | warning | info

**Components:**
- `Notification` - Single notification
- `NotificationContainer` - Container for multiple notifications

### Loader
**File:** `src/components/common/Loader.jsx`

Loading spinners.

**Components:**
- `Loader` - Inline loader with optional text
- `PageLoader` - Full-page loading screen

### Input
**File:** `src/components/common/Input.jsx`

Styled input field with label and error states.

## 📊 Dashboard Components

### StatCard
**File:** `src/components/dashboard/StatCard.jsx`

Statistics display card.

**Props:**
- `icon`: Lucide icon
- `label`: string
- `value`: string | number
- `color`: emerald | amber | rose | blue | purple
- `trend`: up | down (optional)
- `trendValue`: string (optional)

### ProgressBar
**File:** `src/components/dashboard/ProgressBar.jsx`

Animated progress bar.

**Props:**
- `progress`: number (0-100)
- `color`: emerald | amber | rose | blue
- `label`: string (optional)
- `showPercentage`: boolean

### LevelInfo
**File:** `src/components/dashboard/LevelInfo.jsx`

Level configuration display.

**Props:**
- `level`: L3 | L4 | L5

## 📚 Session Components

### SessionCard
**File:** `src/components/sessions/SessionCard.jsx`

Session overview card with status indicators.

**Props:**
- `session`: session object
- `level`: L3 | L4 | L5
- `onClick`: function

**Session States:**
- Locked (document not read)
- In Progress (document read, task active)
- Completed (task submitted)

### SessionModal
**File:** `src/components/sessions/SessionModal.jsx`

Full session workflow modal.

**Props:**
- `session`: session object
- `level`: L3 | L4 | L5
- `isOpen`: boolean
- `onClose`: function
- `onDocumentRead`: function
- `onTaskSubmit`: function

**Features:**
- Two-step workflow (Document → Task)
- Progress indicator
- Deadline countdown

### DocumentReader
**File:** `src/components/sessions/DocumentReader.jsx`

Study material reader interface.

**Props:**
- `session`: session object
- `config`: level configuration
- `onRead`: function - Called when document is confirmed as read

### TaskSubmission
**File:** `src/components/sessions/TaskSubmission.jsx`

Task submission interface with file upload.

**Props:**
- `session`: session object
- `config`: level configuration
- `onSubmit`: function - Called with (sessionId, file)

## 👥 Supervisor Components

### StudentTable
**File:** `src/components/supervisor/StudentTable.jsx`

Students overview table.

**Props:**
- `students`: array of student objects
- `onSelectStudent`: function

**Features:**
- Sortable columns
- Progress visualization
- Status indicators

### StudentDetailModal
**File:** `src/components/supervisor/StudentDetailModal.jsx`

Individual student details modal.

**Props:**
- `student`: student object
- `isOpen`: boolean
- `onClose`: function
- `onApprove`: function - Approve certificate
- `onExtend`: function - Extend deadline

## 🎣 Custom Hooks

### useSession
**File:** `src/hooks/useSession.js`

Session management operations.

**Methods:**
- `markDocumentAsRead(sessionId)`
- `submitTask(sessionId, file)`

**Returns:** { loading, error, markDocumentAsRead, submitTask }

### useTimer / useCountdown
**File:** `src/hooks/useTimer.js`

Timer and countdown utilities.

**useTimer:**
- Countdown from initial seconds
- Methods: start, pause, reset
- Returns: { seconds, isActive, formatted, start, pause, reset }

**useCountdown:**
- Countdown to specific deadline
- Auto-updates every second
- Returns: { timeRemaining, formatted, isExpired }

### useNotification
**File:** `src/hooks/useNotification.js`

Notification system hook.

**Methods:**
- `success(message)`
- `error(message)`
- `warning(message)`
- `info(message)`

## 📝 Usage Examples

### Complete Session Workflow

```jsx
import { SessionCard, SessionModal } from '@components';
import { useSession, useNotification } from '@hooks';

function SessionList() {
  const [selectedSession, setSelectedSession] = useState(null);
  const { markDocumentAsRead, submitTask } = useSession();
  const notification = useNotification();

  const handleDocumentRead = async (sessionId) => {
    const result = await markDocumentAsRead(sessionId);
    if (result.success) {
      notification.success('Document marked as read!');
    }
  };

  const handleSubmit = async (sessionId, file) => {
    const result = await submitTask(sessionId, file);
    if (result.success) {
      notification.success('Task submitted successfully!');
      setSelectedSession(null);
    }
  };

  return (
    <>
      {sessions.map(session => (
        <SessionCard
          key={session.id}
          session={session}
          level="L3"
          onClick={() => setSelectedSession(session)}
        />
      ))}
      
      <SessionModal
        session={selectedSession}
        level="L3"
        isOpen={!!selectedSession}
        onClose={() => setSelectedSession(null)}
        onDocumentRead={handleDocumentRead}
        onTaskSubmit={handleSubmit}
      />
    </>
  );
}
```

## 🎨 Styling Guidelines

All components use:
- Tailwind CSS utility classes
- Consistent spacing (p-4, p-6, p-8)
- Color system from `tailwind.config.js`
- Level-specific colors (L3=emerald, L4=amber, L5=rose)
- Glassmorphism effects (`backdrop-blur-xl`)
- Smooth transitions (`transition-all duration-200`)

## 🔧 Adding New Components

1. Create component file in appropriate directory
2. Export from `src/components/index.js`
3. Follow existing naming conventions
4. Use TypeScript-style prop validation with PropTypes
5. Add documentation in this file
