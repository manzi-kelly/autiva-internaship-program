import React from 'react';
import { Lock, Unlock, CheckCircle, Clock } from 'lucide-react';
import { LEVEL_CONFIG } from '../../constants/levelConfig';

export default function SessionCard({ session, level, onClick }) {
  const config = LEVEL_CONFIG[level];
  const isLocked = !session.documentRead;
  const isActive = session.documentRead && !session.submitted;
  const isCompleted = session.submitted;

  return (
    <div
      onClick={!isLocked ? onClick : undefined}
      className={`bg-slate-900/50 backdrop-blur-xl rounded-2xl p-6 border transition-all ${
        isLocked
          ? 'border-slate-800 opacity-60 cursor-not-allowed'
          : 'border-slate-700 hover:border-slate-600 cursor-pointer hover:shadow-lg'
      }`}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center space-x-3 mb-2">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
              isCompleted ? `${config.colorClasses.bgLight} ${config.colorClasses.text}`
                : isLocked ? 'bg-slate-800 text-slate-600'
                : 'bg-slate-800 text-slate-400'
            }`}>
              {isLocked ? <Lock className="w-5 h-5" /> : 
               isCompleted ? <CheckCircle className="w-5 h-5" /> : 
               <Unlock className="w-5 h-5" />}
            </div>
            <div>
              <h4 className="font-semibold text-white">{session.title}</h4>
              <div className="flex items-center space-x-2 text-sm text-slate-400 mt-1">
                {isCompleted && (
                  <span className={`font-medium ${config.colorClasses.text}`}>
                    Score: {session.score}/100
                  </span>
                )}
                {isActive && (
                  <>
                    <Clock className="w-4 h-4" />
                    <span>{session.timeRemaining}h remaining</span>
                  </>
                )}
                {isLocked && <span>Read document to unlock</span>}
              </div>
            </div>
          </div>
        </div>
        
        <div className={`px-3 py-1 rounded-lg text-xs font-semibold ${
          isCompleted ? `${config.colorClasses.bgLight} ${config.colorClasses.text}` :
          isActive ? 'bg-blue-500/20 text-blue-400' :
          'bg-slate-700 text-slate-400'
        }`}>
          {isCompleted ? 'Completed' : isActive ? 'In Progress' : 'Locked'}
        </div>
      </div>
    </div>
  );
}
