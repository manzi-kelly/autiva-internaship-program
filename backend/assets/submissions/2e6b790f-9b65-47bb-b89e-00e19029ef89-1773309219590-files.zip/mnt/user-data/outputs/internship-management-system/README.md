# 🎓 InternHub - Internship Management System

Professional React application for managing educational internship programs with level-based learning, time-tracked sessions, and automated certificates.

## ✨ Key Features

- **Level-Based Learning** (L3/L4/L5) with customized curricula
- **Document-First Workflow**: Read materials before tasks
- **Time-Tracked Sessions**: Countdown timers with deadline enforcement
- **Progress Tracking**: Visual dashboards and analytics
- **File Submission System**: Upload project files
- **Certificate Generation**: Automatic eligibility checking
- **Role-Based Access**: Student and Supervisor dashboards

## 🛠 Tech Stack

- React 18 + Vite
- React Router 6
- Tailwind CSS
- Lucide Icons
- Axios for API calls
- date-fns for dates

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## 📁 Project Structure

```
src/
├── components/        # Reusable React components
│   ├── auth/         # Login, Register forms
│   ├── dashboard/    # StatCard, ProgressBar
│   ├── sessions/     # SessionCard, Modal
│   ├── supervisor/   # Admin components
│   └── common/       # Button, Modal, etc.
├── pages/            # Page components
├── contexts/         # React Context (Auth, App)
├── utils/            # API calls, helpers
├── constants/        # Configs, endpoints
├── hooks/            # Custom hooks
└── assets/           # Images, fonts
```

## 🎯 Level System

**L3 - Frontend** (10 sessions, 8hr each)
- HTML, CSS, Web Layout
- Pass: 8/10 sessions

**L4 - Backend** (5 sessions, 10hr each)  
- MySQL, PHP, Node.js
- Pass: 4/5 sessions

**L5 - Full-Stack** (3 projects, 48hr each)
- React, CRUD, Databases
- Pass: All 3 projects

## 🔐 Environment Setup

Create `.env`:
```env
VITE_API_BASE_URL=http://localhost:5000/api
```

## 📚 Documentation

See full documentation in the source files and inline comments.

## 🤝 Contributing

Fork, create feature branch, commit, push, and open PR.

---
Built with ❤️ for professional education
