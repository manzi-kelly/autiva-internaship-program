import React, { useState } from 'react';
import { FileText, Upload, AlertCircle } from 'lucide-react';
import Button from '../common/Button';

export default function TaskSubmission({ session, config, onSubmit }) {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
    }
  };

  const handleSubmit = async () => {
    if (!file) return;
    setUploading(true);
    
    // Simulate upload
    await new Promise(resolve => setTimeout(resolve, 2000));
    onSubmit(session.id, file);
    setUploading(false);
  };

  return (
    <div className="space-y-6">
      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
        <div className="flex items-start space-x-4 mb-4">
          <FileText className={`w-6 h-6 ${config.colorClasses.text}`} />
          <div>
            <h4 className="font-semibold text-white mb-2">Practical Task</h4>
            <p className="text-slate-400">
              Apply what you've learned by completing this hands-on assignment. Your submission will be 
              evaluated based on functionality, code quality, and adherence to best practices.
            </p>
          </div>
        </div>

        <div className="bg-slate-900/50 rounded-xl p-6 border border-slate-700 mt-4 space-y-4">
          <h5 className="font-semibold text-white">Assignment Requirements:</h5>
          <ul className="space-y-2 text-slate-300">
            <li className="flex items-start space-x-2">
              <span className={config.colorClasses.text}>•</span>
              <span>Create a functional implementation based on the concepts from the study material</span>
            </li>
            <li className="flex items-start space-x-2">
              <span className={config.colorClasses.text}>•</span>
              <span>Follow best practices and maintain clean, readable code</span>
            </li>
            <li className="flex items-start space-x-2">
              <span className={config.colorClasses.text}>•</span>
              <span>Test your solution thoroughly before submission</span>
            </li>
            <li className="flex items-start space-x-2">
              <span className={config.colorClasses.text}>•</span>
              <span>Submit your work as a compressed file (.zip)</span>
            </li>
          </ul>
        </div>
      </div>

      {/* File Upload */}
      <div className="border-2 border-dashed border-slate-700 rounded-2xl p-8 text-center hover:border-slate-600 transition-colors">
        <Upload className="w-12 h-12 mx-auto mb-4 text-slate-500" />
        <div className="text-slate-300 mb-2">
          {file ? file.name : 'Drop your project files here or click to browse'}
        </div>
        {file && (
          <div className="text-sm text-slate-500 mb-4">
            {(file.size / 1024 / 1024).toFixed(2)} MB
          </div>
        )}
        <input
          type="file"
          onChange={handleFileChange}
          className="hidden"
          id="file-upload"
          accept=".zip,.rar,.7z"
        />
        <label
          htmlFor="file-upload"
          className="inline-block px-6 py-3 bg-slate-800 hover:bg-slate-700 text-white rounded-xl cursor-pointer transition-colors"
        >
          Choose File
        </label>
      </div>

      <div className="flex items-start space-x-3 bg-rose-500/10 border border-rose-500/30 rounded-xl p-4">
        <AlertCircle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
        <div className="text-sm text-rose-200">
          <strong>Deadline Warning:</strong> You have {session.timeRemaining} hours remaining. 
          Submissions after the deadline will receive a score of 0.
        </div>
      </div>

      <Button
        onClick={handleSubmit}
        disabled={!file}
        loading={uploading}
        variant="primary"
        fullWidth
      >
        Submit Task
      </Button>
    </div>
  );
}
